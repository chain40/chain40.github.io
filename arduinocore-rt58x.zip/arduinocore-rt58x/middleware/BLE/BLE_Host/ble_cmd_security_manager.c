/** @file ble_cmd_security_manager.c
 *
 * @brief Define BLE security manager command definition, structure and functions.
 *
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include <string.h>
#include "FreeRTOS.h"
#include "ble_api.h"
#include "ble_security_manager.h"
#include "ble_printf.h"

/**************************************************************************************************
 *    PUBLIC FUNCTIONS
 *************************************************************************************************/

/** BLE send security request.
 *
 */
ble_err_t ble_cmd_security_request_set(uint8_t host_id)
{
    int status;
    ble_tlv_t                       *p_ble_tlv;
    ble_sm_security_request_param_t *p_sec_req_param;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t) + sizeof(ble_sm_security_request_param_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_SM_SECURITY_REQ_SET;
        p_ble_tlv->length = sizeof(ble_sm_security_request_param_t);
        p_sec_req_param = (ble_sm_security_request_param_t *)p_ble_tlv->value;
        p_sec_req_param->host_id = host_id;

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_SM_SECURITY_REQ_SET> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_SM_SECURITY_REQ_SET> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}

/** Set BLE Pairing PassKey Value
 */
ble_err_t ble_cmd_passkey_set(ble_sm_passkey_param_t *p_param)
{
    int status;
    ble_tlv_t              *p_ble_tlv;
    ble_sm_passkey_param_t *ble_passkey_param;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t) + sizeof(ble_sm_passkey_param_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_SM_PASSKEY_SET;
        p_ble_tlv->length = sizeof(ble_sm_passkey_param_t);
        ble_passkey_param = (ble_sm_passkey_param_t *)p_ble_tlv->value;
        ble_passkey_param->host_id = p_param->host_id;
        ble_passkey_param->passkey = p_param->passkey;

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_SM_PASSKEY_SET> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_SM_PASSKEY_SET> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}

/** Set BLE IO Capabilities
 */
ble_err_t ble_cmd_io_capability_set(ble_sm_io_cap_param_t *p_param)
{
    int status;
    ble_tlv_t             *p_ble_tlv;
    ble_sm_io_cap_param_t *ble_io_param;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t) + sizeof(ble_sm_io_cap_param_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_SM_IO_CAPABILITY_SET;
        p_ble_tlv->length = sizeof(ble_sm_io_cap_param_t);
        ble_io_param = (ble_sm_io_cap_param_t *)p_ble_tlv->value;
        ble_io_param->io_caps_param = p_param->io_caps_param;

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_SM_IO_CAPABILITY_SET> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_SM_IO_CAPABILITY_SET> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}

/** Set BLE Bonding Flags
 */
ble_err_t ble_cmd_bonding_flag_set(ble_sm_bonding_flag_param_t *p_param)
{
    int status;
    ble_tlv_t                   *p_ble_tlv;
    ble_sm_bonding_flag_param_t *ble_bonding_flag_param;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t) + sizeof(ble_sm_bonding_flag_param_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_SM_BONDING_FLAG_SET;
        p_ble_tlv->length = sizeof(ble_sm_bonding_flag_param_t);
        ble_bonding_flag_param = (ble_sm_bonding_flag_param_t *)p_ble_tlv->value;
        ble_bonding_flag_param->bonding_flag = p_param->bonding_flag;

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_SM_IO_CAPABILITY_SET> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_SM_IO_CAPABILITY_SET> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}

/** BLE retoste cccd command
 */
ble_err_t ble_cmd_cccd_restore(uint8_t host_id)
{
    int status;
    ble_tlv_t                   *p_ble_tlv;
    ble_sm_restore_cccd_param_t *ble_cccd_param;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t) + sizeof(ble_sm_restore_cccd_param_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_SM_CCCD_RESTORE;
        p_ble_tlv->length = sizeof(ble_sm_restore_cccd_param_t);
        ble_cccd_param = (ble_sm_restore_cccd_param_t *)p_ble_tlv->value;
        ble_cccd_param->host_id = host_id;

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_SM_CCCD_RESTORE> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_SM_CCCD_RESTORE> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}

/** BLE bonding space init
 */
ble_err_t ble_cmd_bonding_space_init(void)
{
    int status;
    ble_tlv_t *p_ble_tlv;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_SM_BOND_SPACE_INIT;
        p_ble_tlv->length = 0;

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_SM_BOND_SPACE_INIT> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_SM_BOND_SPACE_INIT> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}
