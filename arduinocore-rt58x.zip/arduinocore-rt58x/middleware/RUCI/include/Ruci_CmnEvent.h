/******************************************************************************
*
* @File			Ruci_CmnEvent.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_CMN_EVENT_H
#define _RUCI_CMN_EVENT_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_CMN)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_CMN_EVENT_HEADER 0x3F

// RUCI: CmnCnfEvent -----------------------------------------------------------
#define RUCI_CMN_CNF_EVENT                      RUCI_NUM_CMN_CNF_EVENT, Ruci_ElmtType_CmnCnfEvent, Ruci_ElmtNum_CmnCnfEvent
#define RUCI_CODE_CMN_CNF_EVENT                 0x01
#define RUCI_LEN_CMN_CNF_EVENT                  6
#define RUCI_NUM_CMN_CNF_EVENT                  6
#define RUCI_PARA_LEN_CMN_CNF_EVENT             3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_CmnCnfEvent[];
extern const uint8_t Ruci_ElmtNum_CmnCnfEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_CMN_CNF_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         CmnCmdHeader;
    uint8_t         CmnCmdSubheader;
    uint8_t         Status;
} sRUCI_PARA_CMN_CNF_EVENT;

// RUCI: GetFwVerEvent ---------------------------------------------------------
#define RUCI_GET_FW_VER_EVENT                   RUCI_NUM_GET_FW_VER_EVENT, Ruci_ElmtType_GetFwVerEvent, Ruci_ElmtNum_GetFwVerEvent
#define RUCI_CODE_GET_FW_VER_EVENT              0x02
#define RUCI_LEN_GET_FW_VER_EVENT               14
#define RUCI_NUM_GET_FW_VER_EVENT               8
#define RUCI_PARA_LEN_GET_FW_VER_EVENT          11
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetFwVerEvent[];
extern const uint8_t Ruci_ElmtNum_GetFwVerEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_FW_VER_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        FwVer;
    uint8_t         ChipModel;
    uint8_t         ChipVer;
    uint8_t         FeatureId;
    uint32_t        RuciFwVer;
} sRUCI_PARA_GET_FW_VER_EVENT;

// RUCI: SetCalibrationEnableEvent ---------------------------------------------
#define RUCI_SET_CALIBRATION_ENABLE_EVENT       RUCI_NUM_SET_CALIBRATION_ENABLE_EVENT, Ruci_ElmtType_SetCalibrationEnableEvent, Ruci_ElmtNum_SetCalibrationEnableEvent
#define RUCI_CODE_SET_CALIBRATION_ENABLE_EVENT  0x03
#define RUCI_LEN_SET_CALIBRATION_ENABLE_EVENT   10
#define RUCI_NUM_SET_CALIBRATION_ENABLE_EVENT   7
#define RUCI_PARA_LEN_SET_CALIBRATION_ENABLE_EVENT 7
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetCalibrationEnableEvent[];
extern const uint8_t Ruci_ElmtNum_SetCalibrationEnableEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_CALIBRATION_ENABLE_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         Status;
    uint8_t         RxFilter;
    uint8_t         TxLo[2];
    uint8_t         TxSb[3];
} sRUCI_PARA_SET_CALIBRATION_ENABLE_EVENT;

// RUCI: GetTemperatureRptEvent ------------------------------------------------
#define RUCI_GET_TEMPERATURE_RPT_EVENT          RUCI_NUM_GET_TEMPERATURE_RPT_EVENT, Ruci_ElmtType_GetTemperatureRptEvent, Ruci_ElmtNum_GetTemperatureRptEvent
#define RUCI_CODE_GET_TEMPERATURE_RPT_EVENT     0x04
#define RUCI_LEN_GET_TEMPERATURE_RPT_EVENT      8
#define RUCI_NUM_GET_TEMPERATURE_RPT_EVENT      5
#define RUCI_PARA_LEN_GET_TEMPERATURE_RPT_EVENT 5
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetTemperatureRptEvent[];
extern const uint8_t Ruci_ElmtNum_GetTemperatureRptEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_TEMPERATURE_RPT_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        TimeStamp;
    uint8_t         Termperature;
} sRUCI_PARA_GET_TEMPERATURE_RPT_EVENT;

// RUCI: GetVoltageRptEvent ----------------------------------------------------
#define RUCI_GET_VOLTAGE_RPT_EVENT              RUCI_NUM_GET_VOLTAGE_RPT_EVENT, Ruci_ElmtType_GetVoltageRptEvent, Ruci_ElmtNum_GetVoltageRptEvent
#define RUCI_CODE_GET_VOLTAGE_RPT_EVENT         0x05
#define RUCI_LEN_GET_VOLTAGE_RPT_EVENT          8
#define RUCI_NUM_GET_VOLTAGE_RPT_EVENT          5
#define RUCI_PARA_LEN_GET_VOLTAGE_RPT_EVENT     5
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetVoltageRptEvent[];
extern const uint8_t Ruci_ElmtNum_GetVoltageRptEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_VOLTAGE_RPT_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        TimeStamp;
    uint8_t         Voltage;
} sRUCI_PARA_GET_VOLTAGE_RPT_EVENT;

#pragma pack(pop)
#endif /* RUCI_ENABLE_CMN */
#endif /* _RUCI_CMN_EVENT_H */
