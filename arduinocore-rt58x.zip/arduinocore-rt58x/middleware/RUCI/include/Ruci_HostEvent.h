/******************************************************************************
*
* @File			Ruci_HostEvent.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_HOST_EVENT_H
#define _RUCI_HOST_EVENT_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_SF)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_HOST_EVENT_HEADER 0xF1

// RUCI: McuState --------------------------------------------------------------
#define RUCI_MCU_STATE                          RUCI_NUM_MCU_STATE, Ruci_ElmtType_McuState, Ruci_ElmtNum_McuState
#define RUCI_CODE_MCU_STATE                     0x01
#define RUCI_LEN_MCU_STATE                      4
#define RUCI_NUM_MCU_STATE                      4
#define RUCI_PARA_LEN_MCU_STATE                 1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_McuState[];
extern const uint8_t Ruci_ElmtNum_McuState[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_MCU_STATE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         McuState;
} sRUCI_PARA_MCU_STATE;

// RUCI: HostCnfEvent ----------------------------------------------------------
#define RUCI_HOST_CNF_EVENT                     RUCI_NUM_HOST_CNF_EVENT, Ruci_ElmtType_HostCnfEvent, Ruci_ElmtNum_HostCnfEvent
#define RUCI_CODE_HOST_CNF_EVENT                0x02
#define RUCI_LEN_HOST_CNF_EVENT                 6
#define RUCI_NUM_HOST_CNF_EVENT                 6
#define RUCI_PARA_LEN_HOST_CNF_EVENT            3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_HostCnfEvent[];
extern const uint8_t Ruci_ElmtNum_HostCnfEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_HOST_CNF_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         CmdHeader;
    uint8_t         CmdSubheader;
    uint8_t         Status;
} sRUCI_PARA_HOST_CNF_EVENT;

// RUCI: ApciIntState ----------------------------------------------------------
#define RUCI_APCI_INT_STATE                     RUCI_NUM_APCI_INT_STATE, Ruci_ElmtType_ApciIntState, Ruci_ElmtNum_ApciIntState
#define RUCI_CODE_APCI_INT_STATE                0x03
#define RUCI_LEN_APCI_INT_STATE                 5
#define RUCI_NUM_APCI_INT_STATE                 5
#define RUCI_PARA_LEN_APCI_INT_STATE            2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_ApciIntState[];
extern const uint8_t Ruci_ElmtNum_ApciIntState[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_APCI_INT_STATE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         IntState;
    uint8_t         McuState;
} sRUCI_PARA_APCI_INT_STATE;

#pragma pack(pop)
#endif /* RUCI_ENABLE_SF */
#endif /* _RUCI_HOST_EVENT_H */
