/******************************************************************************
*
* @File			Ruci_PciSlinkCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_SLINK_CMD_H
#define _RUCI_PCI_SLINK_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_SLINK_CMD_HEADER 0x15

// RUCI: InitiateSlink ---------------------------------------------------------
#define RUCI_INITIATE_SLINK                     RUCI_NUM_INITIATE_SLINK, Ruci_ElmtType_InitiateSlink, Ruci_ElmtNum_InitiateSlink
#define RUCI_CODE_INITIATE_SLINK                0x01
#define RUCI_LEN_INITIATE_SLINK                 3
#define RUCI_NUM_INITIATE_SLINK                 3
#define RUCI_PARA_LEN_INITIATE_SLINK            0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_InitiateSlink[];
extern const uint8_t Ruci_ElmtNum_InitiateSlink[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_INITIATE_SLINK {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_INITIATE_SLINK;

// RUCI: SetSlinkModem ---------------------------------------------------------
#define RUCI_SET_SLINK_MODEM                    RUCI_NUM_SET_SLINK_MODEM, Ruci_ElmtType_SetSlinkModem, Ruci_ElmtNum_SetSlinkModem
#define RUCI_CODE_SET_SLINK_MODEM               0x02
#define RUCI_LEN_SET_SLINK_MODEM                5
#define RUCI_NUM_SET_SLINK_MODEM                5
#define RUCI_PARA_LEN_SET_SLINK_MODEM           2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetSlinkModem[];
extern const uint8_t Ruci_ElmtNum_SetSlinkModem[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_SLINK_MODEM {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         Bandwidth;
    uint8_t         AutoConfigMode;
} sRUCI_PARA_SET_SLINK_MODEM;

// RUCI: SetSlinkCad -----------------------------------------------------------
#define RUCI_SET_SLINK_CAD                      RUCI_NUM_SET_SLINK_CAD, Ruci_ElmtType_SetSlinkCad, Ruci_ElmtNum_SetSlinkCad
#define RUCI_CODE_SET_SLINK_CAD                 0x03
#define RUCI_LEN_SET_SLINK_CAD                  10
#define RUCI_NUM_SET_SLINK_CAD                  7
#define RUCI_PARA_LEN_SET_SLINK_CAD             7
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetSlinkCad[];
extern const uint8_t Ruci_ElmtNum_SetSlinkCad[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_SLINK_CAD {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         StatusCountNumber;
    uint8_t         StatusThreshold;
    uint8_t         PreambleCountNumber;
    uint32_t        CadOnTime;
} sRUCI_PARA_SET_SLINK_CAD;

// RUCI: SetSlinkCmnPara -------------------------------------------------------
#define RUCI_SET_SLINK_CMN_PARA                 RUCI_NUM_SET_SLINK_CMN_PARA, Ruci_ElmtType_SetSlinkCmnPara, Ruci_ElmtNum_SetSlinkCmnPara
#define RUCI_CODE_SET_SLINK_CMN_PARA            0x04
#define RUCI_LEN_SET_SLINK_CMN_PARA             6
#define RUCI_NUM_SET_SLINK_CMN_PARA             6
#define RUCI_PARA_LEN_SET_SLINK_CMN_PARA        3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetSlinkCmnPara[];
extern const uint8_t Ruci_ElmtNum_SetSlinkCmnPara[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_SLINK_CMN_PARA {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         Sf;
    uint8_t         CodeRate;
    uint8_t         De;
} sRUCI_PARA_SET_SLINK_CMN_PARA;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_SLINK_CMD_H */
