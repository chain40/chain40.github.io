/******************************************************************************
*
* @File			Ruci_Pci15p4MacCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI15P4_MAC_CMD_H
#define _RUCI_PCI15P4_MAC_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI15P4_MAC_CMD_HEADER 0x13

// RUCI: InitiateZigbee --------------------------------------------------------
#define RUCI_INITIATE_ZIGBEE                    RUCI_NUM_INITIATE_ZIGBEE, Ruci_ElmtType_InitiateZigbee, Ruci_ElmtNum_InitiateZigbee
#define RUCI_CODE_INITIATE_ZIGBEE               0x01
#define RUCI_LEN_INITIATE_ZIGBEE                3
#define RUCI_NUM_INITIATE_ZIGBEE                3
#define RUCI_PARA_LEN_INITIATE_ZIGBEE           0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_InitiateZigbee[];
extern const uint8_t Ruci_ElmtNum_InitiateZigbee[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_INITIATE_ZIGBEE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_INITIATE_ZIGBEE;

// RUCI: Set15p4AddressFilter --------------------------------------------------
#define RUCI_SET15P4_ADDRESS_FILTER             RUCI_NUM_SET15P4_ADDRESS_FILTER, Ruci_ElmtType_Set15p4AddressFilter, Ruci_ElmtNum_Set15p4AddressFilter
#define RUCI_CODE_SET15P4_ADDRESS_FILTER        0x02
#define RUCI_LEN_SET15P4_ADDRESS_FILTER         17
#define RUCI_NUM_SET15P4_ADDRESS_FILTER         8
#define RUCI_PARA_LEN_SET15P4_ADDRESS_FILTER    14
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_Set15p4AddressFilter[];
extern const uint8_t Ruci_ElmtNum_Set15p4AddressFilter[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET15P4_ADDRESS_FILTER {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         MacPromiscuousMode;
    uint16_t        ShortSourceAddress;
    uint32_t        LongSourceAddress[2];
    uint16_t        PanId;
    uint8_t         IsCoordinator;
} sRUCI_PARA_SET15P4_ADDRESS_FILTER;

// RUCI: Set15p4MacPib ---------------------------------------------------------
#define RUCI_SET15P4_MAC_PIB                    RUCI_NUM_SET15P4_MAC_PIB, Ruci_ElmtType_Set15p4MacPib, Ruci_ElmtNum_Set15p4MacPib
#define RUCI_CODE_SET15P4_MAC_PIB               0x03
#define RUCI_LEN_SET15P4_MAC_PIB                19
#define RUCI_NUM_SET15P4_MAC_PIB                10
#define RUCI_PARA_LEN_SET15P4_MAC_PIB           16
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_Set15p4MacPib[];
extern const uint8_t Ruci_ElmtNum_Set15p4MacPib[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET15P4_MAC_PIB {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        AUnitBackoffPeriod;
    uint32_t        MacAckWaitDuration;
    uint8_t         MacMaxBE;
    uint8_t         MacMaxCSMABackoffs;
    uint32_t        MacMaxFrameTotalWaitTime;
    uint8_t         MacMaxFrameRetries;
    uint8_t         MacMinBE;
} sRUCI_PARA_SET15P4_MAC_PIB;

// RUCI: Set15p4AutoAck --------------------------------------------------------
#define RUCI_SET15P4_AUTO_ACK                   RUCI_NUM_SET15P4_AUTO_ACK, Ruci_ElmtType_Set15p4AutoAck, Ruci_ElmtNum_Set15p4AutoAck
#define RUCI_CODE_SET15P4_AUTO_ACK              0x04
#define RUCI_LEN_SET15P4_AUTO_ACK               4
#define RUCI_NUM_SET15P4_AUTO_ACK               4
#define RUCI_PARA_LEN_SET15P4_AUTO_ACK          1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_Set15p4AutoAck[];
extern const uint8_t Ruci_ElmtNum_Set15p4AutoAck[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET15P4_AUTO_ACK {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         AutoAckEnableFlag;
} sRUCI_PARA_SET15P4_AUTO_ACK;

// RUCI: Set15p4PhyPib ---------------------------------------------------------
#define RUCI_SET15P4_PHY_PIB                    RUCI_NUM_SET15P4_PHY_PIB, Ruci_ElmtType_Set15p4PhyPib, Ruci_ElmtNum_Set15p4PhyPib
#define RUCI_CODE_SET15P4_PHY_PIB               0x05
#define RUCI_LEN_SET15P4_PHY_PIB                9
#define RUCI_NUM_SET15P4_PHY_PIB                7
#define RUCI_PARA_LEN_SET15P4_PHY_PIB           6
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_Set15p4PhyPib[];
extern const uint8_t Ruci_ElmtNum_Set15p4PhyPib[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET15P4_PHY_PIB {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint16_t        ATurnaroundTime;
    uint8_t         PhyCcaMode;
    uint8_t         PhyCcaThreshold;
    uint16_t        PhyCcaDuration;
} sRUCI_PARA_SET15P4_PHY_PIB;

// RUCI: Set15p4PendingBit -----------------------------------------------------
#define RUCI_SET15P4_PENDING_BIT                RUCI_NUM_SET15P4_PENDING_BIT, Ruci_ElmtType_Set15p4PendingBit, Ruci_ElmtNum_Set15p4PendingBit
#define RUCI_CODE_SET15P4_PENDING_BIT           0x06
#define RUCI_LEN_SET15P4_PENDING_BIT            4
#define RUCI_NUM_SET15P4_PENDING_BIT            4
#define RUCI_PARA_LEN_SET15P4_PENDING_BIT       1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_Set15p4PendingBit[];
extern const uint8_t Ruci_ElmtNum_Set15p4PendingBit[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET15P4_PENDING_BIT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         FramePendingBit;
} sRUCI_PARA_SET15P4_PENDING_BIT;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI15P4_MAC_CMD_H */
