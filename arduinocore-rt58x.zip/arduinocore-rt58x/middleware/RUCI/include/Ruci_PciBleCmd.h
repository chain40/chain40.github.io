/******************************************************************************
*
* @File			Ruci_PciBleCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_BLE_CMD_H
#define _RUCI_PCI_BLE_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_BLE_CMD_HEADER 0x12

// RUCI: InitiateBle -----------------------------------------------------------
#define RUCI_INITIATE_BLE                       RUCI_NUM_INITIATE_BLE, Ruci_ElmtType_InitiateBle, Ruci_ElmtNum_InitiateBle
#define RUCI_CODE_INITIATE_BLE                  0x01
#define RUCI_LEN_INITIATE_BLE                   3
#define RUCI_NUM_INITIATE_BLE                   3
#define RUCI_PARA_LEN_INITIATE_BLE              0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_InitiateBle[];
extern const uint8_t Ruci_ElmtNum_InitiateBle[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_INITIATE_BLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_INITIATE_BLE;

// RUCI: SetBleModem -----------------------------------------------------------
#define RUCI_SET_BLE_MODEM                      RUCI_NUM_SET_BLE_MODEM, Ruci_ElmtType_SetBleModem, Ruci_ElmtNum_SetBleModem
#define RUCI_CODE_SET_BLE_MODEM                 0x02
#define RUCI_LEN_SET_BLE_MODEM                  5
#define RUCI_NUM_SET_BLE_MODEM                  5
#define RUCI_PARA_LEN_SET_BLE_MODEM             2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetBleModem[];
extern const uint8_t Ruci_ElmtNum_SetBleModem[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_BLE_MODEM {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         DataRate;
    uint8_t         CodedScheme;
} sRUCI_PARA_SET_BLE_MODEM;

// RUCI: SetBleMac -------------------------------------------------------------
#define RUCI_SET_BLE_MAC                        RUCI_NUM_SET_BLE_MAC, Ruci_ElmtType_SetBleMac, Ruci_ElmtNum_SetBleMac
#define RUCI_CODE_SET_BLE_MAC                   0x03
#define RUCI_LEN_SET_BLE_MAC                    13
#define RUCI_NUM_SET_BLE_MAC                    7
#define RUCI_PARA_LEN_SET_BLE_MAC               10
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetBleMac[];
extern const uint8_t Ruci_ElmtNum_SetBleMac[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_BLE_MAC {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        SfdContent;
    uint8_t         WhiteningEn;
    uint8_t         WhiteningInitValue;
    uint32_t        CrcInitValue;
} sRUCI_PARA_SET_BLE_MAC;

// RUCI: SetHtrpPara -----------------------------------------------------------
#define RUCI_SET_HTRP_PARA                      RUCI_NUM_SET_HTRP_PARA, Ruci_ElmtType_SetHtrpPara, Ruci_ElmtNum_SetHtrpPara
#define RUCI_CODE_SET_HTRP_PARA                 0x04
#define RUCI_LEN_SET_HTRP_PARA                  23
#define RUCI_NUM_SET_HTRP_PARA                  13
#define RUCI_PARA_LEN_SET_HTRP_PARA             20
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetHtrpPara[];
extern const uint8_t Ruci_ElmtNum_SetHtrpPara[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_HTRP_PARA {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         type;
    uint8_t         block_num;
    uint8_t         min_drift_time;
    uint8_t         max_drift_time;
    uint16_t        drift_low_bond;
    uint16_t        drift_high_bond;
    uint16_t        rx_time;
    uint16_t        ifs;
    uint32_t        pSlot;
    uint32_t        slot;
} sRUCI_PARA_SET_HTRP_PARA;

// RUCI: SetHtrpMapChannel -----------------------------------------------------
#define RUCI_SET_HTRP_MAP_CHANNEL               RUCI_NUM_SET_HTRP_MAP_CHANNEL, Ruci_ElmtType_SetHtrpMapChannel, Ruci_ElmtNum_SetHtrpMapChannel
#define RUCI_CODE_SET_HTRP_MAP_CHANNEL          0x05
#define RUCI_LEN_SET_HTRP_MAP_CHANNEL           45
#define RUCI_NUM_SET_HTRP_MAP_CHANNEL           6
#define RUCI_PARA_LEN_SET_HTRP_MAP_CHANNEL      42
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetHtrpMapChannel[];
extern const uint8_t Ruci_ElmtNum_SetHtrpMapChannel[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_HTRP_MAP_CHANNEL {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         map_num;
    uint8_t         start_num;
    uint8_t         map[40];
} sRUCI_PARA_SET_HTRP_MAP_CHANNEL;

// RUCI: SetHtrpSec ------------------------------------------------------------
#define RUCI_SET_HTRP_SEC                       RUCI_NUM_SET_HTRP_SEC, Ruci_ElmtType_SetHtrpSec, Ruci_ElmtNum_SetHtrpSec
#define RUCI_CODE_SET_HTRP_SEC                  0x06
#define RUCI_LEN_SET_HTRP_SEC                   36
#define RUCI_NUM_SET_HTRP_SEC                   6
#define RUCI_PARA_LEN_SET_HTRP_SEC              33
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetHtrpSec[];
extern const uint8_t Ruci_ElmtNum_SetHtrpSec[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_HTRP_SEC {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         need_sec;
    uint8_t         nonce[16];
    uint8_t         key[16];
} sRUCI_PARA_SET_HTRP_SEC;

// RUCI: SetHtrpTxEnable -------------------------------------------------------
#define RUCI_SET_HTRP_TX_ENABLE                 RUCI_NUM_SET_HTRP_TX_ENABLE, Ruci_ElmtType_SetHtrpTxEnable, Ruci_ElmtNum_SetHtrpTxEnable
#define RUCI_CODE_SET_HTRP_TX_ENABLE            0x07
#define RUCI_LEN_SET_HTRP_TX_ENABLE             3
#define RUCI_NUM_SET_HTRP_TX_ENABLE             3
#define RUCI_PARA_LEN_SET_HTRP_TX_ENABLE        0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetHtrpTxEnable[];
extern const uint8_t Ruci_ElmtNum_SetHtrpTxEnable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_HTRP_TX_ENABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_HTRP_TX_ENABLE;

// RUCI: SetHtrpRxEnable -------------------------------------------------------
#define RUCI_SET_HTRP_RX_ENABLE                 RUCI_NUM_SET_HTRP_RX_ENABLE, Ruci_ElmtType_SetHtrpRxEnable, Ruci_ElmtNum_SetHtrpRxEnable
#define RUCI_CODE_SET_HTRP_RX_ENABLE            0x08
#define RUCI_LEN_SET_HTRP_RX_ENABLE             3
#define RUCI_NUM_SET_HTRP_RX_ENABLE             3
#define RUCI_PARA_LEN_SET_HTRP_RX_ENABLE        0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetHtrpRxEnable[];
extern const uint8_t Ruci_ElmtNum_SetHtrpRxEnable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_HTRP_RX_ENABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_HTRP_RX_ENABLE;

// RUCI: SetHtrpDisable --------------------------------------------------------
#define RUCI_SET_HTRP_DISABLE                   RUCI_NUM_SET_HTRP_DISABLE, Ruci_ElmtType_SetHtrpDisable, Ruci_ElmtNum_SetHtrpDisable
#define RUCI_CODE_SET_HTRP_DISABLE              0x09
#define RUCI_LEN_SET_HTRP_DISABLE               3
#define RUCI_NUM_SET_HTRP_DISABLE               3
#define RUCI_PARA_LEN_SET_HTRP_DISABLE          0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetHtrpDisable[];
extern const uint8_t Ruci_ElmtNum_SetHtrpDisable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_HTRP_DISABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_HTRP_DISABLE;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_BLE_CMD_H */
