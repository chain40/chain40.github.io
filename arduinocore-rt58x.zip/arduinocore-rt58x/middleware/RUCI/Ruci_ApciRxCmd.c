/******************************************************************************
*
* @File			Ruci_ApciRxCmd.c
* @Version
* $Revision:4157
* $Date: 2021-12-27
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_ApciRxCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_APCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SetRxOn ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRxOn[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRxOn[] = {
    1, 1, 1
};

// RUCI: SetRxOff --------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRxOff[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRxOff[] = {
    1, 1, 1
};

#endif /* RUCI_ENABLE_APCI */
#endif /* RUCI_ENDIAN_INVERSE */
