/******************************************************************************
*
* @File			Ruci_PciData.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciData.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SetTxControlField -----------------------------------------------------
const uint8_t Ruci_ElmtType_SetTxControlField[] = {
    1, 1, 2, 1, 1
};
const uint8_t Ruci_ElmtNum_SetTxControlField[] = {
    1, 1, 1, 1, 1
};

// RUCI: RxControlField --------------------------------------------------------
const uint8_t Ruci_ElmtType_RxControlField[] = {
    1, 1, 2, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_RxControlField[] = {
    1, 1, 1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
