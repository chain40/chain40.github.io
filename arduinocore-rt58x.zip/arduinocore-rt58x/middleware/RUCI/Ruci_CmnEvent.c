/******************************************************************************
*
* @File			Ruci_CmnEvent.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_CmnEvent.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_CMN)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: CmnCnfEvent -----------------------------------------------------------
const uint8_t Ruci_ElmtType_CmnCnfEvent[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_CmnCnfEvent[] = {
    1, 1, 1, 1, 1, 1
};

// RUCI: GetFwVerEvent ---------------------------------------------------------
const uint8_t Ruci_ElmtType_GetFwVerEvent[] = {
    1, 1, 1, 4, 1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_GetFwVerEvent[] = {
    1, 1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetCalibrationEnableEvent ---------------------------------------------
const uint8_t Ruci_ElmtType_SetCalibrationEnableEvent[] = {
    1, 1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetCalibrationEnableEvent[] = {
    1, 1, 1, 1, 1, 2, 3
};

// RUCI: GetTemperatureRptEvent ------------------------------------------------
const uint8_t Ruci_ElmtType_GetTemperatureRptEvent[] = {
    1, 1, 1, 4, 1
};
const uint8_t Ruci_ElmtNum_GetTemperatureRptEvent[] = {
    1, 1, 1, 1, 1
};

// RUCI: GetVoltageRptEvent ----------------------------------------------------
const uint8_t Ruci_ElmtType_GetVoltageRptEvent[] = {
    1, 1, 1, 4, 1
};
const uint8_t Ruci_ElmtNum_GetVoltageRptEvent[] = {
    1, 1, 1, 1, 1
};

#endif /* RUCI_ENABLE_CMN */
#endif /* RUCI_ENDIAN_INVERSE */
