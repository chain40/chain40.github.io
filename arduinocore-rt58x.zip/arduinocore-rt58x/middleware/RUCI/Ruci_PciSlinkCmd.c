/******************************************************************************
*
* @File			Ruci_PciSlinkCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciSlinkCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: InitiateSlink ---------------------------------------------------------
const uint8_t Ruci_ElmtType_InitiateSlink[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_InitiateSlink[] = {
    1, 1, 1
};

// RUCI: SetSlinkModem ---------------------------------------------------------
const uint8_t Ruci_ElmtType_SetSlinkModem[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetSlinkModem[] = {
    1, 1, 1, 1, 1
};

// RUCI: SetSlinkCad -----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetSlinkCad[] = {
    1, 1, 1, 1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_SetSlinkCad[] = {
    1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetSlinkCmnPara -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetSlinkCmnPara[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetSlinkCmnPara[] = {
    1, 1, 1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
