/******************************************************************************
*
* @File			Ruci_HostCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_HostCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_SF)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SfrRead ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_SfrRead[] = {
    1, 1, 2, 1
};
const uint8_t Ruci_ElmtNum_SfrRead[] = {
    1, 1, 1, 1
};

// RUCI: SfrWrite --------------------------------------------------------------
const uint8_t Ruci_ElmtType_SfrWrite[] = {
    1, 1, 2, 1, 1
};
const uint8_t Ruci_ElmtNum_SfrWrite[] = {
    1, 1, 1, 1, 1
};

// RUCI: IoRead ----------------------------------------------------------------
const uint8_t Ruci_ElmtType_IoRead[] = {
    1, 1, 2, 1, 2
};
const uint8_t Ruci_ElmtNum_IoRead[] = {
    1, 1, 1, 1, 1
};

// RUCI: IoWrite ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_IoWrite[] = {
    1, 1, 2, 1, 2, 1
};
const uint8_t Ruci_ElmtNum_IoWrite[] = {
    1, 1, 1, 1, 1, 2110
};

// RUCI: MemRead ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_MemRead[] = {
    1, 1, 2, 2, 2
};
const uint8_t Ruci_ElmtNum_MemRead[] = {
    1, 1, 1, 1, 1
};

// RUCI: MemWrite --------------------------------------------------------------
const uint8_t Ruci_ElmtType_MemWrite[] = {
    1, 1, 2, 2, 2, 1
};
const uint8_t Ruci_ElmtNum_MemWrite[] = {
    1, 1, 1, 1, 1, 2048
};

// RUCI: RegRead ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_RegRead[] = {
    1, 1, 2, 4
};
const uint8_t Ruci_ElmtNum_RegRead[] = {
    1, 1, 1, 1
};

// RUCI: RegWrite --------------------------------------------------------------
const uint8_t Ruci_ElmtType_RegWrite[] = {
    1, 1, 2, 4, 4
};
const uint8_t Ruci_ElmtNum_RegWrite[] = {
    1, 1, 1, 1, 1
};

// RUCI: PmuCfgByRf ------------------------------------------------------------
const uint8_t Ruci_ElmtType_PmuCfgByRf[] = {
    1, 1, 2, 1
};
const uint8_t Ruci_ElmtNum_PmuCfgByRf[] = {
    1, 1, 1, 1
};

#endif /* RUCI_ENABLE_SF */
#endif /* RUCI_ENDIAN_INVERSE */
