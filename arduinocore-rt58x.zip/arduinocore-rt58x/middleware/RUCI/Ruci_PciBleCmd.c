/******************************************************************************
*
* @File			Ruci_PciBleCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciBleCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: InitiateBle -----------------------------------------------------------
const uint8_t Ruci_ElmtType_InitiateBle[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_InitiateBle[] = {
    1, 1, 1
};

// RUCI: SetBleModem -----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetBleModem[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetBleModem[] = {
    1, 1, 1, 1, 1
};

// RUCI: SetBleMac -------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetBleMac[] = {
    1, 1, 1, 4, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_SetBleMac[] = {
    1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetHtrpPara -----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetHtrpPara[] = {
    1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4
};
const uint8_t Ruci_ElmtNum_SetHtrpPara[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetHtrpMapChannel -----------------------------------------------------
const uint8_t Ruci_ElmtType_SetHtrpMapChannel[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetHtrpMapChannel[] = {
    1, 1, 1, 1, 1, 40
};

// RUCI: SetHtrpSec ------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetHtrpSec[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetHtrpSec[] = {
    1, 1, 1, 1, 16, 16
};

// RUCI: SetHtrpTxEnable -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetHtrpTxEnable[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetHtrpTxEnable[] = {
    1, 1, 1
};

// RUCI: SetHtrpRxEnable -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetHtrpRxEnable[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetHtrpRxEnable[] = {
    1, 1, 1
};

// RUCI: SetHtrpDisable --------------------------------------------------------
const uint8_t Ruci_ElmtType_SetHtrpDisable[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetHtrpDisable[] = {
    1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
