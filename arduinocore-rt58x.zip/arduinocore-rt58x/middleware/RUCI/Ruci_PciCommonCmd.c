/******************************************************************************
*
* @File			Ruci_PciCommonCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciCommonCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SetRfFrequency --------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfFrequency[] = {
    1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_SetRfFrequency[] = {
    1, 1, 1, 1
};

// RUCI: SetRxEnable -----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRxEnable[] = {
    1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_SetRxEnable[] = {
    1, 1, 1, 1
};

// RUCI: SetSingleToneMode -----------------------------------------------------
const uint8_t Ruci_ElmtType_SetSingleToneMode[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetSingleToneMode[] = {
    1, 1, 1, 1
};

// RUCI: GetCrcCount -----------------------------------------------------------
const uint8_t Ruci_ElmtType_GetCrcCount[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetCrcCount[] = {
    1, 1, 1
};

// RUCI: SetRfSleep ------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfSleep[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfSleep[] = {
    1, 1, 1, 1
};

// RUCI: SetRfIdle -------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfIdle[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfIdle[] = {
    1, 1, 1
};

// RUCI: SetDutyCycle ----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetDutyCycle[] = {
    1, 1, 1, 4, 4
};
const uint8_t Ruci_ElmtNum_SetDutyCycle[] = {
    1, 1, 1, 1, 1
};

// RUCI: GetRssi ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_GetRssi[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetRssi[] = {
    1, 1, 1
};

// RUCI: GetPhyStatus ----------------------------------------------------------
const uint8_t Ruci_ElmtType_GetPhyStatus[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetPhyStatus[] = {
    1, 1, 1
};

// RUCI: SetClockMode ----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetClockMode[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetClockMode[] = {
    1, 1, 1, 1, 1, 1
};

// RUCI: SetRfbAutoState -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfbAutoState[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfbAutoState[] = {
    1, 1, 1, 1
};

// RUCI: SetRfeSecurity --------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfeSecurity[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfeSecurity[] = {
    1, 1, 1, 16, 13
};

// RUCI: SetRfeTxEnable --------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfeTxEnable[] = {
    1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 4, 1, 2, 2
};
const uint8_t Ruci_ElmtNum_SetRfeTxEnable[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetRfeTxDisable -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfeTxDisable[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfeTxDisable[] = {
    1, 1, 1
};

// RUCI: SetRfeRxEnable --------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfeRxEnable[] = {
    1, 1, 1, 1, 1, 1, 1, 4, 1, 2, 1, 2, 2
};
const uint8_t Ruci_ElmtNum_SetRfeRxEnable[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetRfeRxDisable -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfeRxDisable[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfeRxDisable[] = {
    1, 1, 1
};

// RUCI: SetRfeMode ------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfeMode[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfeMode[] = {
    1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
