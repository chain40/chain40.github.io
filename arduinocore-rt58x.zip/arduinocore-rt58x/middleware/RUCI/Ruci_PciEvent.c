/******************************************************************************
*
* @File			Ruci_PciEvent.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciEvent.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: CnfEvent --------------------------------------------------------------
const uint8_t Ruci_ElmtType_CnfEvent[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_CnfEvent[] = {
    1, 1, 1, 1, 1, 1
};

// RUCI: GetRegEvent -----------------------------------------------------------
const uint8_t Ruci_ElmtType_GetRegEvent[] = {
    1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_GetRegEvent[] = {
    1, 1, 1, 1
};

// RUCI: GetCrcReportEvent -----------------------------------------------------
const uint8_t Ruci_ElmtType_GetCrcReportEvent[] = {
    1, 1, 1, 4, 4
};
const uint8_t Ruci_ElmtNum_GetCrcReportEvent[] = {
    1, 1, 1, 1, 1
};

// RUCI: DtmBurstTxDoneEvent ---------------------------------------------------
const uint8_t Ruci_ElmtType_DtmBurstTxDoneEvent[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_DtmBurstTxDoneEvent[] = {
    1, 1, 1
};

// RUCI: GetRssiEvent ----------------------------------------------------------
const uint8_t Ruci_ElmtType_GetRssiEvent[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetRssiEvent[] = {
    1, 1, 1, 1
};

// RUCI: GetPhyStatusEvent -----------------------------------------------------
const uint8_t Ruci_ElmtType_GetPhyStatusEvent[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetPhyStatusEvent[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
