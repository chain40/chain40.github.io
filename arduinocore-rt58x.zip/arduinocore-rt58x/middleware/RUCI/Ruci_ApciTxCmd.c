/******************************************************************************
*
* @File			Ruci_ApciTxCmd.c
* @Version
* $Revision:4157
* $Date: 2021-12-27
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_ApciTxCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_APCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SetTxOn ---------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetTxOn[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetTxOn[] = {
    1, 1, 1
};

#endif /* RUCI_ENABLE_APCI */
#endif /* RUCI_ENDIAN_INVERSE */
