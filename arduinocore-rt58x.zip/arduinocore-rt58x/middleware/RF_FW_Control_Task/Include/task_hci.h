/** @file task_hci.h
 *
 * @brief Handle BLE HCI command, event and ACL data.
 *
 * @addtogroup BLE
 * @{
 * @addtogroup Task
 * @{
 * @defgroup task_hci BLE HCI Task
 * @{ @}
 * @}
 * @}
 */

#ifndef __TASK_HCI_H__
#define __TASK_HCI_H__

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include "sys_arch.h"
#include "project_config.h"
#include "comm_subsystem_ahb_phy.h"
#include "rf_common_init.h"
#include "ble_host_ref.h"

/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/

#define PHY_STATUS                          (0x05)     /**< Length of PHY status (HW generate). */
#define CRC                                 (0x03)     /**< Length of CRC (HW generate).*/
#define MIC                                 (0x04)     /**< Length of MIC (HW generate).*/
#define HCI_PKT_IND                         (0x01)     /**< Length of HCI packet indicator. */
#define HANDLE_PB_PC                        (0x02)     /**< Length of HCI ACL data header, handle + PB +PC. */
#define DATA_TOTAL_LEN                      (0x02)     /**< Length of HCI ACL data header, data total length. */

#define BLE_TRANSPORT_HCI_COMMAND           (0x01)     /**< HCI packet indicators for command packet. */
#define BLE_TRANSPORT_HCI_ACL_DATA          (0x02)     /**< HCI packet indicators for ACL data packet. */
#define BLE_TRANSPORT_HCI_EVENT             (0x04)     /**< HCI packet indicators for event packet. */

#define HCI_ACL_DATA_MAX_LENGTH             (251+MIC)  /**< Maximum ACL data length. */



/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/

typedef enum hci_msg_tag_def
{
    HCI_MSG_BASE = 0x0010,       /**< Message base for upper layer */
    HCI_MSG_HOST_HCI_CMD,              /**< Message for upper layer to notify TX HCI command */
    HCI_MSG_HOST_HCI_ACL_DATA,             /**< Message for upper layer to notify TX ACL data */
    HCI_MSG_HOST_NOCP_EVENT,               /**< Message for Host to notify HCI how much data complete*/
    HCI_MSG_MAX = 0x0020,
} hci_msg_tag_def_t;



/**@brief
 * @ingroup task_hci
 */

typedef struct __attribute__((packed)) ble_hci_command_hdr_s
{
    uint8_t transport_id; /**< Transport id. */
    uint16_t ocf: 10;     /**< Opcode command field. */
    uint16_t ogf: 6;      /**< Opcode group field. */
    uint8_t length;       /**< Length. */
    uint8_t parameter[];  /**< Parameters. */
} ble_hci_command_hdr_t;



/**@brief
 * @ingroup task_hci
 */
typedef struct __attribute__((packed)) ble_hci_rx_acl_data_hdr_s
{
    uint8_t transport_id;  /**< Transport id. */
    uint16_t handle: 12;   /**< Connection id. */
    uint16_t pb_flag: 2;   /**< Packet boundary flag. */
    uint16_t bc_flag: 2;   /**< Broadcast flag. */
    uint16_t length;       /**< Data total length. */
    uint8_t data[];        /**< ACL data. */
} ble_hci_rx_acl_data_hdr_t;


/**@brief
 * @ingroup task_hci
 */
typedef struct __attribute__((packed)) ble_hci_tx_acl_data_hdr_s
{
    uint8_t transport_id;   /**< Transport id. */
    uint8_t sequence;       /**< Sequence number. */
    uint16_t handle: 12;    /**< Connection id. */
    uint16_t pb_flag: 2;    /**< Packet boundary flag. */
    uint16_t bc_flag: 2;    /**< Broadcast flag. */
    uint16_t length;        /**< Data total length. */
    uint8_t data[];         /**< ACL data. */
} ble_hci_tx_acl_data_hdr_t;


/**@brief
 * @ingroup task_hci
 */
typedef struct __attribute__((packed)) ble_hci_event_s
{
    uint8_t transport_id;  /**< Transport id. */
    uint8_t event_code;    /**< Event. */
    uint8_t length;        /**< Event parameter length. */
    uint8_t parameter[];   /**< Parameter. */
} ble_hci_event_t;


/**@brief
 * @ingroup task_hci
 */
typedef struct __attribute__((packed)) ble_hci_acl_data_complete_event_s
{
    uint16_t complete_num;  /**< Complete data number. */
} ble_hci_acl_data_complete_event_t;


/**@brief
 * @ingroup task_hci
 */
typedef struct ble_hci_message_struct_s
{
    union
    {
        uint8_t                           ble_hci_array[HCI_ACL_DATA_MAX_LENGTH + PHY_STATUS + CRC + HCI_PKT_IND + HANDLE_PB_PC + DATA_TOTAL_LEN];  /**< maximum array that hci task able to receive*/
        ble_hci_command_hdr_t             hci_command;       /**< HCI command format send to the controller. */
        ble_hci_tx_acl_data_hdr_t         hci_tx_acl_data;   /**< HCI ACL data format send to the controller. */
        ble_hci_rx_acl_data_hdr_t         hci_rx_acl_data;   /**< HCI ACL data format get from the controller. */
        ble_hci_event_t                   hci_event;         /**< HCI event format get from the controller. */
        ble_hci_acl_data_complete_event_t hci_data;          /**< ACL data complete number event get from host. */
    } msg_type;
} ble_hci_message_struct_t;


/**@brief
 * @ingroup task_hci
 */
typedef struct hci_task_common_queue
{
    uint32_t hci_msg_tag;                     /**< hci message tag. */
    ble_hci_message_struct_t *hci_msg_ptr;    /**< hci message pointer. */
} hci_task_common_queue_t;


/**************************************************************************
 * EXTERN DEFINITIONS
 **************************************************************************/
/**@brief The handle of HCI common queue.
 * @ingroup task_hci
 */


/**@brief The handle of HCI TX ACL data queue.
 * @ingroup task_hci
 */
extern sys_queue_t g_hci_common_handle;

extern sys_queue_t g_hci_tx_acl_handle;


/**@brief The handle of HCI TX command queue.
 * @ingroup task_hci
 */
extern sys_queue_t g_hci_tx_cmd_handle;


/**************************************************************************************************
 *    PUBLIC FUNCTIONS
 *************************************************************************************************/

/**@brief BLE HCI task initialization.
 *
 * @ingroup task_hci
 *
 * @return none
 */
void task_hci_init(void);



#ifdef __cplusplus
};
#endif

#endif /* __TASK_HCI_H__*/
