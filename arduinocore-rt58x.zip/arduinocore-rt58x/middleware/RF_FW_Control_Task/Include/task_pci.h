/** @file task_hci.h
 *
 * @brief Handle BLE HCI command, event and ACL data.
 *
 * @addtogroup BLE
 * @{
 * @addtogroup Task
 * @{
 * @defgroup task_hci BLE HCI Task
 * @{ @}
 * @}
 * @}
 */

#ifndef __TASK_PCI_H__
#define __TASK_PCI_H__

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include "sys_arch.h"
#include "project_config.h"
#include "comm_subsystem_ahb_phy.h"
#include "rf_common_init.h"

/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/

#define TX_SW_QUEUE_FULL             (0xF1)     /**< response by SW, freeRTOS queue full. */
#define TX_MALLOC_FULL               (0xF2)     /**< response by SW, memory allocation fail. */
#define NUM_QUEUE_PCI_DATA           (10)
#define NUM_QUEUE_PCI_CMD            (10)
/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/

/**@brief
 * @ingroup task_hci
 */
typedef enum pci_msg_tag_def
{
    PCI_MSG_BASE = 0x0020,       /**< Message base for upper layer */
    PCI_MSG_TX_PCI_CMD,              /**< Message for upper layer to notify TX HCI command */
    PCI_MSG_TX_PCI_DATA,               /**< Message for Host to notify HCI how much data complete*/
    PCI_MSG_MAX = 0x0030,
} pci_msg_tag_def_t;



/**@brief
 * @ingroup task_hci
 */
typedef struct __attribute__((packed)) pci_15p4_hdr_s
{
    uint8_t     ruci_header;
    uint8_t     sub_header;
    uint8_t     length;
    uint8_t     parameter[];  /**< Parameters. */
} pci_15p4_hdr_t;

typedef struct __attribute__((packed)) pci_15p4_data_hdr_s
{
    uint8_t    ruci_header;
    uint8_t    sub_header;
    uint16_t   length;
    uint8_t    initial_cw_and_ack_request;
    uint8_t    dsn;
    uint8_t    parameter[];  /**< Parameters. */
} pci_15p4_data_hdr_t;



/**@brief
 * @ingroup task_hci
 */

typedef struct pci_message_struct_s
{
    union
    {
        uint8_t                           pci_array[268]; /*HCI_ACL_DATA_MAX_LENGTH + PHY_STATUS + CRC + HCI_PKT_IND + HANDLE_PB_PC + DATA_TOTAL_LEN*/
        pci_15p4_hdr_t                    pci_tx_hdr;
        pci_15p4_data_hdr_t               pci_tx_data_hdr;
    } msg_type;
} pci_message_struct_t;

typedef struct pci_message_param_type_struct_s
{
    union{
        pci_message_struct_t  *pci_msg_ptr; /**< reserved  */
        uint32_t pci_msg_var;   /**< for tx done interrupt */
   }param_type;
}pci_message_param_type_struct_t;


typedef struct pci_task_common_queue
{
    uint32_t pci_msg_tag;                      /**< hci message tag. */
    pci_message_param_type_struct_t pci_msg;   /**< for tx done interrupt */
} pci_task_common_queue_t;

/**************************************************************************
 * EXTERN DEFINITIONS
 **************************************************************************/
/**@brief The handle of HCI common queue.
 * @ingroup task_hci
 */
extern sys_queue_t g_pci_common_handle;


/**@brief The handle of HCI TX ACL data queue.
 * @ingroup task_hci
 */
extern sys_queue_t g_pci_tx_data_handle;


/**@brief The handle of HCI TX command queue.
 * @ingroup task_hci
 */
extern sys_queue_t g_pci_tx_cmd_handle;


/**************************************************************************************************
 *    PUBLIC FUNCTIONS
 *************************************************************************************************/

/**@brief BLE HCI task initialization.
 *
 * @ingroup task_hci
 *
 * @return none
 */
void task_pci_init(void);

void send_data_to_pci_fail(uint8_t reason);


#ifdef __cplusplus
};
#endif

#endif /* __TASK_PCI_H__*/
