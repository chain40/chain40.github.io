// ---------------------------------------------------------------------------
// Copyright (c) 2021
// All rights reserved.
//
// ---------------------------------------------------------------------------
#ifndef __SYS_TIMER_H__
#define __SYS_TIMER_H__

#ifdef __cplusplus
extern "C" {
#endif

//=============================================================================
//                Include (Better to prevent)
//=============================================================================
#include "sys_arch.h"

//=============================================================================
//                Public Definitions of const value
//=============================================================================
#define SYS_MAX_TIMER                0xFFFFFFFF
#define SYS_TIMER_MAX_PERIOD         0x0A4CB800  // 172800000 ms = 48 hour
#define SYS_TIMER_SHIFT_THRESHOLD    0x80000000  // About 24.8 day

//############################################################
// SYS Timer Tick = 0.1 ms
// MAX Time = 48 Hour = 2880 min = 172800 sec =  172800000 ms
//############################################################
#define SYS_TIMER_HOUR_TO_TICK(h)            ((h) * 3600000)
#define SYS_TIMER_MINUTE_TO_TICK(m)          ((m) * 60000)
#define SYS_TIMER_SECOND_TO_TICK(s)          ((s) * 1000)
#define SYS_TIMER_MILLISECOND_TO_TICK(ms)    (ms)

//=============================================================================
//                Public ENUM
//=============================================================================
typedef enum SYS_TIMER_PRIORITY
{
    SYS_TIMER_PRIORITY_0 = 0,    // Low
    SYS_TIMER_PRIORITY_MAX,
} sys_timer_pri_t;

typedef enum SYS_TIMER_EXECUTE_MODE
{
    SYS_TIMER_EXECUTE_ONCE_FOR_EACH_TIMEOUT      = 0,
    SYS_TIMER_EXECUTE_ONCE_FOR_DUPLICATE_TIMEOUT = 1,
} sys_timer_mode_t;

typedef enum SYS_TIMER_ERRNO
{
    SYS_TIMER_EXECUTE_MODE_FAIL  = -5,
    SYS_TIMER_PERIOD_FAIL        = -4,
    SYS_TIMER_PRIORITY_FAIL      = -3,
    SYS_TIMER_CMD_SEND_FAIL      = -2,
    SYS_TIMER_NULL               = -1,
    SYS_TIMER_PASS               = 0,
} sys_timer_err_t;

//=============================================================================
//                Public Struct
//=============================================================================
typedef void (*sys_timer_cb)(void *p_param);

typedef struct SYS_TIMER
{
    uint32_t            period;
    const char          *name;

    uint32_t            auto_reload             : 1;
    uint32_t            priority                : 2;
    uint32_t            execute_mode            : 1;    // follow enum sys_timer_execute_mode_e
    uint32_t            receive_delete_cmd      : 1;
    uint32_t            wating_for_execution    : 8;
    uint32_t            running                 : 1;
    uint32_t            reserved                : 18;

    void                *cb_param;
    sys_timer_cb         cb_function;

    uint32_t            timeout;
    link_list_t         list;
} sys_timer_t;

//=============================================================================
//                Public Function Declaration
//=============================================================================
sys_timer_t *sys_timer_create(const char *name, uint32_t period, uint32_t auto_reload, sys_timer_pri_t priority, uint32_t execute_mode, void *cb_param, sys_timer_cb cb_function);
sys_timer_err_t sys_timer_start(sys_timer_t *timer);
sys_timer_err_t sys_timer_stop(sys_timer_t *timer);
sys_timer_err_t sys_timer_reset(sys_timer_t *timer);
sys_timer_err_t sys_timer_change_period(sys_timer_t *timer, uint32_t period);
sys_timer_err_t sys_timer_change_priority(sys_timer_t *timer, uint32_t priority);
sys_timer_err_t sys_timer_change_execute_mode(sys_timer_t *timer, uint32_t execute_mode);
sys_timer_err_t sys_timer_delete(sys_timer_t *timer);
const char *sys_timer_get_timer_name(sys_timer_t *timer);
sys_timer_err_t sys_timer_start_from_isr(sys_timer_t *timer);
sys_timer_err_t sys_timer_stop_from_isr(sys_timer_t *timer);
sys_timer_err_t sys_timer_reset_from_isr(sys_timer_t *timer);
sys_timer_err_t sys_timer_change_period_from_isr(sys_timer_t *timer, uint32_t period);
sys_timer_err_t sys_timer_change_priority_from_isr(sys_timer_t *timer, uint32_t priority);
sys_timer_err_t sys_timer_change_execute_mode_from_isr(sys_timer_t *timer, uint32_t execute_mode);
sys_timer_err_t sys_timer_delete_from_isr(sys_timer_t *timer);
int sys_timer_init(uint32_t u32_hw_timer_id);
void sys_timer_state_print(void);
bool sys_timer_get_running(sys_timer_t *timer);
uint32_t sys_timer_get_tick(void);
#ifdef __cplusplus
};
#endif
#endif /* __SYS_TIMER_H__ */
