/** @file bsp_console.c
 *
 * @license
 * @description
 */

#include "stdint.h"
#include "bsp.h"
#include "cm3_mcu.h"

#include "uart_drv.h"
#include "uart_retarget.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#ifndef DEBUG_CONSOLE_UART_ID
#define UART_ACT_DBG_PORT_ID            0
#else
#define UART_ACT_DBG_PORT_ID            DEBUG_CONSOLE_UART_ID   
#endif

#ifndef DEBUG_CONSOLE_UART_BAUDRATE
#define UART_ACT_BAUD_RATE              UART_BAUDRATE_115200
#else
#define UART_ACT_BAUD_RATE              DEBUG_CONSOLE_UART_BAUDRATE
#endif

#ifndef UART0_USER_HANDLE_RECV_RX  
#define UART0_RX_PIO_MODE               0
#else   
#define UART0_RX_PIO_MODE               UART0_USER_HANDLE_RECV_RX
#endif


#define UART_CACHE_SIZE                 256
#define UART_CACHE_MASK                 (UART_CACHE_SIZE - 1)
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct uart_io
{
    volatile uint32_t wr_idx;
    volatile uint32_t rd_idx;

    volatile uint32_t is_flushing;
    uint8_t uart_cache[UART_CACHE_SIZE];
} uart_io_t;
//=============================================================================
//                  Global Data Definition
//==============================================================================
static uart_io_t g_uart_rx_io = { .wr_idx = 0, .rd_idx = 0, };

#if (UART0_RX_PIO_MODE == 0) 
static uint8_t gu8_uart_rx_cache[4];
#endif

static bsp_event_callback_t m_callback = NULL;
//=============================================================================
//                  Private Function Definition
//=============================================================================
static void uart_isr_event_handle(uint32_t event, void *p_context)
{
    uint32_t  pos;
#if (UART0_RX_PIO_MODE == 1) 
    if(event & UART_EVENT_RX_RECV)
    {       
        pos = (g_uart_rx_io.wr_idx + 1) % UART_CACHE_SIZE;
        if( pos != g_uart_rx_io.rd_idx )
        {
            g_uart_rx_io.uart_cache[g_uart_rx_io.wr_idx] = uart_rx_getbytes(DEBUG_CONSOLE_UART_ID);
            g_uart_rx_io.wr_idx = pos;
            if(m_callback != NULL)
                m_callback(BSP_EVENT_UART_RX_RECV);
        }        
    }
#else
    if (event & UART_EVENT_RX_DONE) 
    {
        pos = (g_uart_rx_io.wr_idx + 1) % UART_CACHE_SIZE;
        if( pos != g_uart_rx_io.rd_idx )
        {
            g_uart_rx_io.uart_cache[g_uart_rx_io.wr_idx] = gu8_uart_rx_cache[0];
            g_uart_rx_io.wr_idx = pos;
            if(m_callback != NULL)
                m_callback(BSP_EVENT_UART_RX_DONE);
        }
        uart_rx(UART_ACT_DBG_PORT_ID, gu8_uart_rx_cache, 1);
    }
#endif
    if(event & UART_EVENT_RX_BREAK)
    {
#if (UART0_RX_PIO_MODE == 1) 
        uart_rx_getbytes(DEBUG_CONSOLE_UART_ID);
        uart_rx_getbytes(DEBUG_CONSOLE_UART_ID);
#endif
        if(m_callback != NULL)
            m_callback(BSP_EVENT_UART_BREAK);
    }
}


//=============================================================================
//                  Public Function Definition
//=============================================================================
int bsp_console_init(bsp_event_callback_t callback)
{
    int     rval = 0;

    uart_config_t debug_console_drv_config;
    uart_retarget_desc_t t_retarget_desc;

    do {

        /*uart0 pinmux*/
        pin_set_mode(16, MODE_UART);     /*GPIO16 as UART0 RX*/
        pin_set_mode(17, MODE_UART);     /*GPIO17 as UART0 TX*/

        /*init debug console uart0, 8bits 1 stopbit, none parity, no flow control.*/
        debug_console_drv_config.baudrate = (uart_baudrate_t)UART_ACT_BAUD_RATE;
        debug_console_drv_config.databits = UART_DATA_BITS_8;
        debug_console_drv_config.hwfc     = UART_HWFC_DISABLED;
        debug_console_drv_config.parity   = UART_PARITY_NONE;
        debug_console_drv_config.stopbit  = UART_STOPBIT_ONE;
        debug_console_drv_config.interrupt_priority = 0x06;
        
        rval = uart_init(UART_ACT_DBG_PORT_ID, &debug_console_drv_config, uart_isr_event_handle);       
    
        if (rval != 0)
            break;

        m_callback = callback;

        t_retarget_desc.uart_id = UART_ACT_DBG_PORT_ID;

        uart_retarget_init(&t_retarget_desc);
#if (UART0_RX_PIO_MODE == 0)
        uart_rx(UART_ACT_DBG_PORT_ID, gu8_uart_rx_cache ,1);
#endif
    } while(0);    
    return rval;
}

int bsp_console_stdio_flush(void)
{
    int     rval = 0;

    NVIC_DisableIRQ(Uart0_IRQn);

    g_uart_rx_io.wr_idx = 0;
    g_uart_rx_io.rd_idx = 0;
    g_uart_rx_io.is_flushing = true;

    NVIC_EnableIRQ(Uart0_IRQn);
    return rval;
}

int bsp_console_deinit(void)
{
    return 0;
}

int bsp_console_stdout_char(int ch)
{
    return uart_retarget_stdout_char(ch);
}

int bsp_console_stdout_string(char *str, int length)
{
    int     rval = 0;
    uart_retarget_stdout_string(str, length);
    return (rval == 0) ? length : 0;
}

int bsp_console_stdin_str(char *pBuf, int length)
{
    int         byte_cnt = 0;
    uint32_t    rd_pos = g_uart_rx_io.rd_idx;
    uint32_t    wr_pos = g_uart_rx_io.wr_idx;

    g_uart_rx_io.is_flushing = 0;

    do {
        while( 1 )
        {
            if( g_uart_rx_io.is_flushing )
            {
                wr_pos = rd_pos = byte_cnt = 0;
                break;
            }
            if( rd_pos == wr_pos ) break;
            if( length == byte_cnt ) break;

            pBuf[byte_cnt++] = g_uart_rx_io.uart_cache[rd_pos];

            rd_pos = (rd_pos + 1) % UART_CACHE_SIZE;
        }
        g_uart_rx_io.rd_idx = rd_pos;
    } while(0);
    return byte_cnt;
}
