/**
 * Copyright (c) 2020 Rex Huang, All Rights Reserved.
 */
/** @file ping.c
 *
 * @author Rex Huang
 * @version 0.1
 * @date 2020/05/28
 * @license
 * @description
 */

//=============================================================================
//                Include
//=============================================================================
#include <stddef.h>

#include "util_log.h"
#include "util_printf.h"
#include "mfs.h"
#include "mfs_define.h"
#include "crc.h"

#include "sys_arch.h"

//=============================================================================
//                Private Definitions of const value
//=============================================================================
#define __file_system_pool          __attribute__ ((used, section("file_system_pool")))

#if defined(__CC_ARM) || defined(__CLANG_ARM)
    extern uint32_t Image$$RW_IROM_FILE_SYSTEM_POOL_START$$RO$$Base;
    extern uint32_t Image$$RW_IROM_FILE_SYSTEM_POOL_START$$RO$$Limit;
#define FILE_SYSTEM_POOL_START    ((void*)&Image$$RW_IROM_FILE_SYSTEM_POOL_START$$RO$$Base)
#define FILE_SYSTEM_POOL_END    ((void*)&Image$$RW_IROM_FILE_SYSTEM_POOL_START$$RO$$Limit)
#else
    extern uint32_t     __file_system_pool_start__;
    extern uint32_t     __file_system_pool_end__;
#define FILE_SYSTEM_POOL_START    ((void*)&__file_system_pool_start__)
#define FILE_SYSTEM_POOL_END    ((void*)&__file_system_pool_start__)
#endif


#define MFS_START_ADDRESS   (uint32_t)FILE_SYSTEM_POOL_START
#define MFS_STORAGE_SIZE    0x1000

#define RT58X_FLASH_BASE_ADDR   0x90000000
const uint8_t cg_file_system_pool[MFS_STORAGE_SIZE] __file_system_pool;
//=============================================================================
//                Private ENUM
//=============================================================================

//=============================================================================
//                Private Struct
//=============================================================================

//=============================================================================
//                Private Function Declaration
//=============================================================================

//=============================================================================
//                Private Global Variables
//=============================================================================
static int opened_files = 0;
static uint8_t Cache_buf[MFS_STORAGE_SIZE];
static DirectoryDescriptor root ;
static FileAllocationTable fat ;
static fs_head_t fs_head;
static uintptr_t startAddress = 0;
//=============================================================================
//                Public Global Variables
//=============================================================================

//=============================================================================
//                Private Definition of Compare/Operation/Inline function/
//=============================================================================
static int getFileID(const char*name, DirectoryDescriptor *rootDir);
static int getFreeNode(FileAllocationTable *fat);
static int getFreePage(FileDescriptor *file, FileAllocationTable *fat);
static int getNextPage(int currNode, FileAllocationTable *pfat);
static int getFileSize(FileDescriptor *file, FileAllocationTable *pfat);
static int readFile(FileDescriptor *pfile, FileAllocationTable *pfat, int length, uint8_t *pdbuf);
static void createFile(const char*name, FileDescriptor *file);
static void initialFileDesc(FileAllocationTable *pfat, DirectoryDescriptor *proot);

//=============================================================================
//                Functions
//=============================================================================
static void _memcpy_ram(uint8_t* dst, uint8_t* src, uint32_t len)
{
    uint32_t i;
    for(i = 0; i<len; i++)
    {
        dst[i] = src[i];
    }
}

static void fc_write(uintptr_t ram_addr, uintptr_t fc_addr, uint32_t size)
{
    int             i;
    int             remain = size;

    uintptr_t       from_pos = 0;
    uintptr_t       to_pos = 0;
    uint32_t        valid_len = 0;
    uint32_t        offset = 0;
    
    offset          = fc_addr & (0x1000  - 1);
    valid_len       = 0x1000 - offset;
    to_pos          = fc_addr & ~(0x1000 - 1);
    from_pos        = ram_addr;

    //info("dw %x -> %x, %d\n", ram_addr, fc_addr, size);

    // read data to cache
    for(i = 0; i < (0x1000 >> 8); i++)
    {        
        while(flash_check_busy());
       // taskENTER_CRITICAL();
        //info("dw %x -> %x, %d\n", (uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], to_pos, size);
        flash_read_page((uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], RT58X_FLASH_BASE_ADDR + to_pos);
        //taskEXIT_CRITICAL();
        
        to_pos += (0x1 << 8);
    }
    to_pos          = fc_addr & ~(0x1000 - 1);

    valid_len = (valid_len < size) ? valid_len : size;

    _memcpy_ram(&((uint8_t*)Cache_buf)[offset], (void*)ram_addr, valid_len);
    from_pos += valid_len;

    while(flash_check_busy());
    //taskENTER_CRITICAL();
    flash_erase(FLASH_ERASE_PAGE, RT58X_FLASH_BASE_ADDR + to_pos);
    //taskEXIT_CRITICAL();
    // page program
    for(i = 0; i < (0x1000 >> 8); i++)
    {        
        while(flash_check_busy());
        //taskENTER_CRITICAL();
        //info("wr %x -> %x, %d\n", (uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], to_pos, valid_len);
        flash_write_page((uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], RT58X_FLASH_BASE_ADDR + to_pos);
        //taskEXIT_CRITICAL();
        
        to_pos += (0x1 << 8);
    }

    remain -= valid_len;

    while( (remain & ~(0x1000 - 1)) )
    {
        // erase sector
        flash_erase(FLASH_ERASE_PAGE, to_pos);
        while(flash_check_busy());

        // page program
        for(i = 0; i < (0x1000 >> 8); i++)
        {
            while(flash_check_busy());
            //taskENTER_CRITICAL();
            flash_write_page(from_pos, RT58X_FLASH_BASE_ADDR + to_pos);
            //taskEXIT_CRITICAL();
            
            from_pos += (0x1 << 8);
            to_pos   += (0x1 << 8);
        }
        
        // update info
        remain -= 0x1000;
    }
    to_pos          = fc_addr & ~(0x1000 - 1);
    if( remain )
    {
        // read data to cache
        for(i = 0; i < (0x1000 >> 8); i++)
        {        
            while(flash_check_busy());
            //taskENTER_CRITICAL();
            info("dw %x -> %x, %d\n", (uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], to_pos, valid_len);
            flash_read_page((uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], RT58X_FLASH_BASE_ADDR + to_pos);
            //taskEXIT_CRITICAL();
            
            to_pos += (0x1 << 8);
        }
        to_pos          = fc_addr & ~(0x1000 - 1);

        // merge data
        _memcpy_ram((void*)Cache_buf, (void*)from_pos, remain);

        // erase sector
        while(flash_check_busy());
        //taskENTER_CRITICAL();
        flash_erase(FLASH_ERASE_PAGE, to_pos);
        //taskEXIT_CRITICAL();
        
        // page program
        for(i = 0; i < (0x1000 >> 8); i++)
        {
            while(flash_check_busy());
            //taskENTER_CRITICAL();
            flash_write_page((uint32_t)&((uint8_t*)Cache_buf)[i * (0x1 << 8)], RT58X_FLASH_BASE_ADDR + to_pos);
            //taskEXIT_CRITICAL();
            to_pos += (0x1 << 8);
        }
    }
}

static void fc_read(uintptr_t ram_addr, uintptr_t fc_addr, uint32_t size)
{
    _memcpy_ram((uint8_t *)ram_addr, (uint8_t *)fc_addr, size);
}

void filesystem_reset(void)
{
    while(flash_check_busy());
    //taskENTER_CRITICAL();
    flash_erase(FLASH_ERASE_PAGE, MFS_START_ADDRESS);
    //taskEXIT_CRITICAL();

    //info("Flash control erase success\n");
    initialFileDesc(&fat, &root);

    _memcpy_ram(fs_head.magic, (uint8_t *)g_mfs_magic, 3);
    fs_head.files = 0;

    fc_write((uint32_t)&fs_head, MFS_START_ADDRESS, sizeof(fs_head_t));          
    fc_write((uint32_t)&root, MFS_START_ADDRESS + FILE_DESCRIB_OFFSET, sizeof(DirectoryDescriptor));
    fc_write((uint32_t)&fat, MFS_START_ADDRESS + DATA_INDEX_TABLE_OFFSET, sizeof(FileAllocationTable));
}

fs_err_t file_system_init(void)
{
    fs_err_t    fs_err = FS_OK;
    uint8_t crc_flag = 0, i;
    do
    {
        //flash_enable_qe();
        flash_set_read_pagesize();

        startAddress = MFS_START_ADDRESS;

        info("File System position : %X, size : %d \n", startAddress, MFS_STORAGE_SIZE);
        fc_read((uint32_t)&fs_head, MFS_START_ADDRESS, sizeof(fs_head));
        fc_read((uint32_t)&root, MFS_START_ADDRESS + FILE_DESCRIB_OFFSET, sizeof(DirectoryDescriptor));
        fc_read((uint32_t)&fat, MFS_START_ADDRESS + DATA_INDEX_TABLE_OFFSET, sizeof(FileAllocationTable));

        for(i=0; i<3; i++)
        {
            if(fs_head.magic[i] != g_mfs_magic[i])
            {
                crc_flag = 1;
                break;
            }
        }
        if(crc_flag == 0)
        {
            info("Magic correct\n");
            fc_read((uint32_t)&root, MFS_START_ADDRESS + FILE_DESCRIB_OFFSET, sizeof(DirectoryDescriptor));
            fc_read((uint32_t)&fat, MFS_START_ADDRESS + DATA_INDEX_TABLE_OFFSET, sizeof(FileAllocationTable));
        }
        else
        {
            info("FileSystem header incorrect, reset\n");
            if(flash_erase(FLASH_ERASE_PAGE, MFS_START_ADDRESS) != 0)
            {
                //info("Flash control erase faild\n");
                fs_err = FS_ERR;

                break;
            }
            while(flash_check_busy());
            //info("Flash control erase success\n");
            initialFileDesc(&fat, &root);

            _memcpy_ram(fs_head.magic, (uint8_t *)g_mfs_magic, 3);
            fs_head.files = 0;

            fc_write((uint32_t)&fs_head, MFS_START_ADDRESS, sizeof(fs_head_t));          
            fc_write((uint32_t)&root, MFS_START_ADDRESS + FILE_DESCRIB_OFFSET, sizeof(DirectoryDescriptor));
            fc_write((uint32_t)&fat, MFS_START_ADDRESS + DATA_INDEX_TABLE_OFFSET, sizeof(FileAllocationTable));

        }
    } while(0);
    return fs_err;
}

int fs_open(const char *FileName)
{
    if(fs_head.files > MAX_FILES)
        return -2;
    int fileID = getFileID(FileName, &root);
    if (fileID != -1)
    {
        return fileID;
    }
    info("File <%s> not found, create.. ", FileName);

    fileID = fs_head.files++;
    createFile(FileName, &(root.table[fileID]));
    info("Success !!\n");
    root.table[fileID].index = getFreeNode(&fat);
    root.table[fileID].ptr = root.table[fileID].index;
    return fileID;
}
fs_err_t fs_close(int fileID)
{
    if (opened_files > MAX_FILES)
    {
        info("Error: File #%d does not exist.\n", fileID);
        return FS_ERR;
    }

    root.table[fileID].opened = 0;
    root.table[fileID].ptr = root.table[fileID].index;
    root.table[fileID].offset = 0;
    int i;
    for (i = 0; i < MAX_DATA_PAGES; i++) {
        fat.table[i].ptr = 0;
    }
    fc_write((uint32_t)&fs_head, MFS_START_ADDRESS, sizeof(fs_head_t)); 
    fc_write((uint32_t)&root, startAddress + FILE_DESCRIB_OFFSET, sizeof(DirectoryDescriptor));
    fc_write((uint32_t)&fat, MFS_START_ADDRESS + DATA_INDEX_TABLE_OFFSET, sizeof(FileAllocationTable));
    return FS_OK;
}
int fs_list(void)
{
    int num_list = 0;
    fs_list_t list;
    do
    {
        int i = 0;
        info("Name\t\tOpend\t\tSize\n");
        for (i = 0; i < MAX_FILES; i++)
        {
            if(root.table[i].index != MAX_DATA_PAGES)
            {
                memcpy(list.fs_st[num_list].filename, root.table[i].filename, 8);
                list.fs_st[num_list].size = root.table[i].size;
                list.fs_st[num_list].opened = root.table[i].opened;
                num_list++;
                info("%s\t%s\t\t%d\n", list.fs_st[i].filename, list.fs_st[i].opened ? "Y" : "N", list.fs_st[i].size);
            }
            else
            {
                continue;
            }
        }
    } while (0);

    return num_list;
}

fs_err_t fs_seek(int fileID, uint32_t offset, e_fs_seek e_type)
{
    if (opened_files > MAX_FILES)
    {
        //info("Error: File #%d does not exist.\n", fileID);
        return FS_ID_INVALID;
    }

    if (offset > root.table[fileID].size)
        return FS_OUT_OF_RANGE;

    uint8_t count = 0, curr_idx = root.table[fileID].index;

    if (e_type == FS_SEEK_TAIL)
    {
        offset = root.table[fileID].size - offset;
    }

    if(offset < DATA_PAGE_SIZE)
    {
        root.table[fileID].offset = offset;
        root.table[fileID].ptr = root.table[fileID].index;
    }
    else
    {
        curr_idx = root.table[fileID].index;
        count = offset / DATA_PAGE_SIZE;

        while(count--)
            curr_idx = getNextPage(curr_idx, &fat);

        root.table[fileID].ptr = curr_idx;
        root.table[fileID].offset = offset % DATA_PAGE_SIZE;
    }
    return FS_OK;
}
size_t fs_write(int fileID, uint8_t *buf, int length)
{
    int addr = 2;
    int temp_len = 0;
    int count = 0;
    int i;
    int remain_len = 0;
    size_t w_size = 0;
    uint8_t w_data[DATA_PAGE_SIZE] = {0};
    
    do
    {
        if(opened_files > MAX_FILES)
        {
            break;
        }

        if(length < DATA_PAGE_SIZE)
        {
            temp_len = DATA_PAGE_SIZE;
            count = 1;
        }
        else
        {
            temp_len = length;
            count = temp_len / DATA_PAGE_SIZE + 1;
        }

        for(i = 0; i < count; i++)
        {            
            memset(w_data, 0, sizeof(w_data));

            addr = root.table[fileID].ptr;

            fc_read((uintptr_t)w_data, MFS_START_ADDRESS + DATA_BLOCK_OFFSET + (addr * DATA_PAGE_SIZE), DATA_PAGE_SIZE);

            remain_len = DATA_PAGE_SIZE - root.table[fileID].offset;
            if(length < remain_len)
                remain_len = length;
            _memcpy_ram(&w_data[root.table[fileID].offset], buf, remain_len);
            buf += remain_len;

            if(addr != MAX_DATA_PAGES && addr >= 0)
            {
                fc_write((uintptr_t)w_data, MFS_START_ADDRESS + DATA_BLOCK_OFFSET + (addr * DATA_PAGE_SIZE), DATA_PAGE_SIZE);
                w_size += length < DATA_PAGE_SIZE ? length : DATA_PAGE_SIZE;
                if((fat.table[addr].ptr + (length < DATA_PAGE_SIZE ? length : DATA_PAGE_SIZE)) >= DATA_PAGE_SIZE)
                    fat.table[addr].ptr = DATA_PAGE_SIZE;
                else
                    fat.table[addr].ptr += length < DATA_PAGE_SIZE ? length : DATA_PAGE_SIZE;



                if (w_size % DATA_PAGE_SIZE == 0)
                {
                    if (getNextPage(addr, &fat) == MAX_DATA_PAGES)
                    {
                        if(length)
                            root.table[fileID].ptr = getFreePage(&(root.table[fileID]), &fat);
                    }
                    else
                    {
                        root.table[fileID].ptr = getNextPage(addr, &fat);
                    }
                }
                root.table[fileID].offset = 0;

                if(length >= DATA_PAGE_SIZE)
                    length -= remain_len;
            }
            else
            {
                break;
            }
        }
        root.table[fileID].size = getFileSize(&(root.table[fileID]), &fat);
        fc_write((uint32_t)&root, MFS_START_ADDRESS + FILE_DESCRIB_OFFSET, sizeof(DirectoryDescriptor));
        fc_write((uint32_t)&fat, MFS_START_ADDRESS + DATA_INDEX_TABLE_OFFSET, sizeof(FileAllocationTable));

    } while(0);

    return w_size;
}
int fs_read(int fileID, uint8_t *buf, int length)
{
    if (opened_files > MAX_FILES && root.table[fileID].opened == 0 )
    {
        //info_color(LOG_RED, "No such file %d is opened\n", fileID);
        return 0;
    }
    if(root.table[fileID].size == 0)
        return EOF;

    return readFile(&(root.table[fileID]), &fat, length, buf);
}
size_t fs_get_file_size(const char *FileName)
{
    size_t filesize = 0;
    do
    {
        int fileID = getFileID(FileName, &root);
        if(fileID == -1)
            break;

        filesize = root.table[fileID].size;

    } while(0);

    return filesize;
}
static void createFile(const char*name, FileDescriptor *file)
{
    uint8_t name_len = 0, i = 0;
    while(name[i++])
    {
        name_len++;
    }
    memcpy(file->filename, name, name_len);
    file->opened = 1;
    file->ptr = 0;
    file->offset = 0;
    file->size   = 0;
}
static int getFileID(const char*name, DirectoryDescriptor *rootDir)
{
    int i = 0, fileID = -1;
    uint8_t name_len = 0;
    while(name[i++])
    {
        name_len++;
    }
    for(i = 0; i < MAX_FILES; i++) {
        if (memcmp(rootDir->table[i].filename, name, name_len) == 0)
        {
            fileID = i;
            break;
        }
    }

    if ( fileID != -1)
    {
        if(rootDir->table[fileID].opened == 1)
        {
            return -2;
        }
    }

    return fileID;
}

static int getFreeNode(FileAllocationTable *pfat)
{
    int i;
    for (i = 0; i < MAX_DATA_PAGES; i++)
    {
        if (pfat->table[i].free)
        {
            pfat->table[i].free = 0;
            return i;
        }
    }
    //info_color(LOG_RED, "Error: Cannot get free block.\n");
    return -1;
}

static int getFreePage(FileDescriptor *file, FileAllocationTable *pfat)
{
    int currNode = file->index;

    //info("pfat->table[%d].next = %d\n", currNode, pfat->table[currNode].next);

    while (pfat->table[currNode].next != MAX_DATA_PAGES) {
        currNode = pfat->table[currNode].next;
        file->ptr = currNode;
    }

    int nextNode = getFreeNode(pfat);
    pfat->table[currNode].next = nextNode;
    pfat->table[nextNode].next = MAX_DATA_PAGES;

    return nextNode < 0 ? -1 : nextNode;
}
static int getNextPage(int currNode, FileAllocationTable *pfat)
{
    currNode = pfat->table[currNode].next;

    return currNode;
}
static int getFileSize(FileDescriptor *file, FileAllocationTable *pfat)
{
    int currNode = file->index;
    int size = 0;
    while (pfat->table[currNode].next != MAX_DATA_PAGES) {
        size += pfat->table[currNode].ptr;
        currNode = pfat->table[currNode].next;
    }
    size += pfat->table[currNode].ptr;
    return size;
}
static int readFile(FileDescriptor *pfile, FileAllocationTable *pfat, int length, uint8_t *pdbuf)
{
    int curr, red = 0;
    int positionOnDisk = 0;
    int remain_len = 0;
    uint8_t *ptr;
    int read_len = 0;

    ptr = pdbuf;

    curr = pfile->ptr;

    for (; length != 0; curr = pfat->table[curr].next, red++) {
        positionOnDisk = curr;

        remain_len = DATA_PAGE_SIZE - pfile->offset;
        if(length < remain_len)
            remain_len = length;

        fc_read((uint32_t)ptr, MFS_START_ADDRESS + DATA_BLOCK_OFFSET + (positionOnDisk * DATA_PAGE_SIZE) + pfile->offset, remain_len);
        pfile->offset = 0;

        length -= remain_len;
        ptr += remain_len;
        read_len += remain_len;
    }
    return read_len;
}

static void initialFileDesc(FileAllocationTable *pfat, DirectoryDescriptor *proot)
{
    int i;
    for (i = 0; i < MAX_DATA_PAGES; i++) {
        pfat->table[i].next = MAX_DATA_PAGES;
        pfat->table[i].free = 1;
        pfat->table[i].ptr = 0;
    }
    for (i = 0; i < MAX_FILES; i++) {
        memset(proot->table[i].filename, 0xff, sizeof(proot->table[i].filename));
        proot->table[i].size = 0;
        proot->table[i].index = MAX_DATA_PAGES;
    }
}




