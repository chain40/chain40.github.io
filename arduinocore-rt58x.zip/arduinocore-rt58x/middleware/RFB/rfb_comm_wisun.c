/**
 * @file rfb_comm_wisun.c
 * @author
 * @date
 * @brief Apis for RFB communication subsystem and ruci format
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include "cm3_mcu.h"
#include "Ruci.h"
#include "rfb_comm.h"
#include "rfb.h"
/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/



/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/



/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/

/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/

/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/

extern RF_MCU_RX_CMDQ_ERROR rfb_event_read(uint8_t *packet_length, uint8_t *event_address);
extern void enter_critical_section(void);
extern void leave_critical_section(void);
extern void rfb_send_cmd(uint8_t *cmd_address, uint8_t cmd_length);
/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
RFB_EVENT_STATUS  rfb_comm_fsk_initiate(uint8_t band_type)
{
    sRUCI_PARA_INITIATE_FSK sGfskInitCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_FSK_INIT(&sGfskInitCmd, band_type);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGfskInitCmd, RUCI_INITIATE_FSK);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGfskInitCmd, RUCI_LEN_INITIATE_FSK);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_INITIATE_FSK)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS  rfb_comm_fsk_modem_set(uint8_t data_rate, uint8_t modulation_index)
{
    sRUCI_PARA_SET_FSK_MODEM sGfskModemSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_FSK_MODEMT(&sGfskModemSetCmd, data_rate, modulation_index);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGfskModemSetCmd, RUCI_SET_FSK_MODEM);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGfskModemSetCmd, RUCI_LEN_SET_FSK_MODEM);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_FSK_MODEM)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS  rfb_comm_fsk_mac_set(uint8_t crc_type, uint8_t whitening_enable)
{
    sRUCI_PARA_SET_FSK_MAC sGfskMacSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_FSK_MAC(&sGfskMacSetCmd, crc_type, whitening_enable);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGfskMacSetCmd, RUCI_SET_FSK_MAC);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGfskMacSetCmd, RUCI_LEN_SET_FSK_MAC);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_FSK_MAC)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS  rfb_comm_fsk_preamble_set(uint8_t preamble_length)
{
    sRUCI_PARA_SET_FSK_PREAMBLE sGfskPreambleSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_FSK_PREAMBLE(&sGfskPreambleSetCmd, preamble_length);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGfskPreambleSetCmd, RUCI_SET_FSK_PREAMBLE);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGfskPreambleSetCmd, RUCI_LEN_SET_FSK_PREAMBLE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_FSK_PREAMBLE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS  rfb_comm_fsk_sfd_set(uint32_t sfd_content)
{
    sRUCI_PARA_SET_FSK_SFD sGfskSfdSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_FSK_SFD(&sGfskSfdSetCmd, sfd_content)

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGfskSfdSetCmd, RUCI_SET_FSK_SFD);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGfskSfdSetCmd, RUCI_LEN_SET_FSK_SFD);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_FSK_SFD)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}
