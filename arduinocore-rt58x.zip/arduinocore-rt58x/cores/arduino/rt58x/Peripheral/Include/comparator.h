/** @file
 *
 * @brief Comparator driver file.
 *
 */

#ifndef __COMPARATOR_H__
#define __COMPARATOR_H__

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/

typedef enum
{
    COMP_CONFIG_INT_POL_RISING      = 0,   /**< Rising edge. */
    COMP_CONFIG_INT_POL_FALLING     = 1,   /**< Falling edge. */
    COMP_CONFIG_INT_POL_BOTH        = 2,   /**< Both edge. */
} comp_config_int_pol_t;

typedef enum
{
    COMP_CONFIG_CHANNEL_0      = 0,   /**< Channel 0. */
    COMP_CONFIG_CHANNEL_1      = 1,   /**< Channel 1. */
    COMP_CONFIG_CHANNEL_2      = 2,   /**< Channel 2. */
    COMP_CONFIG_CHANNEL_3      = 3,   /**< Channel 3. */
    COMP_CONFIG_CHANNEL_4      = 4,   /**< Channel 4. */
    COMP_CONFIG_CHANNEL_5      = 5,   /**< Channel 5. */
    COMP_CONFIG_CHANNEL_6      = 6,   /**< Channel 6. */
    COMP_CONFIG_CHANNEL_7      = 7,   /**< Channel 7. */
    COMP_CONFIG_CHANNEL_MAX    = 8,   /**< Max Channel 8. */
} comp_config_ch_sel_t;

typedef enum
{
    COMP_CONFIG_VOLTAGE_0      = 0,   /**< Voltage 0. */
    COMP_CONFIG_VOLTAGE_1      = 1,   /**< Voltage 1. */
    COMP_CONFIG_VOLTAGE_2      = 2,   /**< Voltage 2. */
    COMP_CONFIG_VOLTAGE_3      = 3,   /**< Voltage 3. */
    COMP_CONFIG_VOLTAGE_4      = 4,   /**< Voltage 4. */
    COMP_CONFIG_VOLTAGE_5      = 5,   /**< Voltage 5. */
    COMP_CONFIG_VOLTAGE_6      = 6,   /**< Voltage 6. */
    COMP_CONFIG_VOLTAGE_7      = 7,   /**< Voltage 7. */
    COMP_CONFIG_VOLTAGE_8      = 8,   /**< Voltage 8. */
    COMP_CONFIG_VOLTAGE_9      = 9,   /**< Voltage 9. */
    COMP_CONFIG_VOLTAGE_10     = 10,  /**< Voltage 10. */
    COMP_CONFIG_VOLTAGE_11     = 11,  /**< Voltage 11. */
    COMP_CONFIG_VOLTAGE_12     = 12,  /**< Voltage 12. */
    COMP_CONFIG_VOLTAGE_13     = 13,  /**< Voltage 13. */
    COMP_CONFIG_VOLTAGE_14     = 14,  /**< Voltage 14. */
    COMP_CONFIG_VOLTAGE_15     = 15,  /**< Voltage 15. */
    COMP_CONFIG_VOLTAGE_MAX    = 16,  /**< Max Voltage 16. */
} comp_config_v_sel_t;

/**
 * @brief Comparator configuration.
 */
typedef struct
{
    comp_config_int_pol_t     comp_int_pol;       /**< Comparator interrupt polarity*/
    comp_config_ch_sel_t      comp_ch_sel;        /**< Comparator AIO channel*/
    comp_config_v_sel_t       comp_v_sel;         /**< Comparator VCCIO voltage*/
} comp_config_t;

/**
 * @brief User cb handler prototype.
 *
 * This function is called when the requested number of samples has been processed.
 *
 * @param p_cb CB.
 */
typedef void (*comp_isr_handler_t)(void);


/**************************************************************************************************
 *    Global Prototypes
 *************************************************************************************************/
#define COMP_ENABLE()                     (PMU->PMU_COMP0.bit.AUX_COMP_EN_NM = ENABLE)        /**< Enable the Comparator module*/
#define COMP_INT_ENABLE()                 (PMU->PMU_COMP0.bit.AUX_COMP_INT_EN = ENABLE)       /**< Enable the Comparator interrupt*/
#define COMP_INT_DISABLE()                (PMU->PMU_COMP0.bit.AUX_COMP_INT_EN = DISABLE)      /**< Disable the Comparator interrupt*/
#define COMP_INT_CLEAR()                  (PMU->PMU_COMP1.bit.AUX_COMP_INT_CLR = ENABLE)      /**< Clear the Comparator interrupt status*/
#define COMP_INT_STATUS_GET()             (PMU->PMU_COMP2.bit.AUX_COMP_INT_STA)               /**< Return the Comparator interrupt status*/
#define COMP_OUT_GET()                    (PMU->PMU_COMP2.bit.AUX_COMP_OUT)                   /**< Return the Comparator output result*/
#define COMP_INT_POL(para_set)            (PMU->PMU_COMP0.bit.AUX_COMP_INT_POL = para_set)    /**< Set the Comparator interrupt polarity*/
#define COMP_CH_SEL(para_set)             (PMU->PMU_COMP0.bit.AUX_COMP_CHSEL = para_set)      /**< Select the Comparator AIO channel for comparision*/
#define COMP_V_SEL(para_set)              (PMU->PMU_COMP0.bit.AUX_COMP_VSEL = para_set)       /**< Select the Comparator VCCIO voltage to compare with selected AIO channel*/


void Comp_Register_Int_Callback(comp_isr_handler_t comp_int_callback);
void Comp_Int_Enable(void);
void Comp_Int_Disable(void);

uint32_t Comp_Init(comp_config_t *p_config, comp_isr_handler_t comp_int_callback);
void Comp_Enable(void);


#endif /* end of _COMPARATOR_H_ */

