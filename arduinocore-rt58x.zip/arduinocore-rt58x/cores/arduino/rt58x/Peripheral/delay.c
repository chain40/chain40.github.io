/** @file
 *
 * @brief Delay driver file.
 *
 */

/**
 * @defgroup Delay Group
 * @{
 * @brief    Delay group.
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include "cm3_mcu.h"


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
static void Delay_us_32MHz(uint32_t volatile number_of_us);
static void Delay_us_48MHz(uint32_t volatile number_of_us);
static void Delay_us_64MHz(uint32_t volatile number_of_us);
static void Delay_ms_32MHz(uint32_t volatile number_of_ms);
static void Delay_ms_48MHz(uint32_t volatile number_of_ms);
static void Delay_ms_64MHz(uint32_t volatile number_of_ms);


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
delay_us_t Delay_us = Delay_us_64MHz;
delay_ms_t Delay_ms = Delay_ms_64MHz;


/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/
static void Delay_us_32MHz(uint32_t volatile number_of_us)
{
    uint32_t R0 __attribute__((unused));

    __asm volatile (
        " loop_32MHz:                      \n"
        "    SUBS    R0, R0, #1            \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    BNE    loop_32MHz_overhead    \n"
        "    B      loop_32MHz_end         \n"
        " loop_32MHz_overhead:             \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    B     loop_32MHz              \n"
        " loop_32MHz_end:                  \n"
    );
}


static void Delay_us_48MHz(uint32_t volatile number_of_us)
{
    uint32_t R0 __attribute__((unused));

    __asm volatile (
        " loop_48MHz:                      \n"
        "    SUBS    R0, R0, #1            \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    BNE    loop_48MHz_overhead    \n"
        "    B      loop_48MHz_end         \n"
        " loop_48MHz_overhead:             \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    B     loop_48MHz              \n"
        " loop_48MHz_end: \n"
    );
}


static void Delay_us_64MHz(uint32_t volatile number_of_us)
{
    uint32_t R0 __attribute__((unused));

    __asm volatile (
        " loop_64MHz:                      \n"
        "    SUBS    R0, R0, #1            \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    BNE    loop_64MHz_overhead    \n"
        "    B      loop_64MHz_end         \n"
        " loop_64MHz_overhead:             \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    NOP                           \n"
        "    B     loop_64MHz              \n"
        " loop_64MHz_end:                  \n"
    );
}


static void Delay_ms_32MHz(uint32_t volatile number_of_ms)
{
    while(number_of_ms != 0) {
        number_of_ms--;
        Delay_us(999);

        if (number_of_ms != 0) {        /*delay for overhead*/
            __asm volatile (
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
            );
        }
    }
}


static void Delay_ms_48MHz(uint32_t volatile number_of_ms)
{
    while(number_of_ms != 0) {
        number_of_ms--;
        Delay_us(999);

        __asm volatile (                         /*fine tune 1us delay time*/
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
        );

        if (number_of_ms != 0) {        /*delay for overhead*/
            __asm volatile (
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
            );
        }
    }
}


static void Delay_ms_64MHz(uint32_t volatile number_of_ms)
{
    while(number_of_ms != 0) {
        number_of_ms--;
        Delay_us(999);

        __asm volatile (                         /*fine tune 1us delay time*/
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
            " NOP \n"
        );

        if (number_of_ms != 0) {        /*delay for overhead*/
            __asm volatile (
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
                " NOP \n"
            );
        }
    }
}


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
void Delay_Init(void)
{
    switch (get_ahb_system_clk())
    {
        case SYS_CLK_32MHZ:
              Delay_us = Delay_us_32MHz;
              Delay_ms = Delay_ms_32MHz;
              break;
        case SYS_CLK_48MHZ:
              Delay_us = Delay_us_48MHz;
              Delay_ms = Delay_ms_48MHz;
              break;
        case SYS_CLK_64MHZ:
              Delay_us = Delay_us_64MHz;
              Delay_ms = Delay_ms_64MHz;
              break;
        default:
              break;
    }
}

