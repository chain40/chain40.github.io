/** @file
 *
 * @brief SAR ADC driver file.
 *
 */

/**
 * @defgroup SADC Group
 * @{
 * @brief    SAR ADC group.
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include "cm3_mcu.h"
#if (SUPPORT_SADC_TEMPERATURE == 1)
#include "comm_subsystem_ahb_phy.h"
#endif


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
#define SADC_VGA_BYPASS         0

#define SADC_CH_REG_OFFSET      4    /*unit: 4-bytes*/

#define SADC_INT_DISABLE_ALL    0xFFFFFFFF
#define SADC_INT_CLEAR_ALL      0xFFFFFFFF

#define SADC_ANALOG_ENABLE      1

#define SADC_CALIBRATION_VALUE  (0)

/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
static sadc_isr_handler_t   sadc_reg_handler = NULL;
static uint32_t sadc_xdma_single_mode = DISABLE;
static sadc_convert_state_t  sadc_convert_state = SADC_CONVERT_IDLE;


/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
extern void commsubsystem_write_memory(uint16_t reg_address, const uint8_t *p_tx_data, uint16_t tx_data_length);
extern void commsubsystem_read_memory(uint16_t reg_address, uint8_t *p_rx_data, uint16_t rx_data_length);

/**
 * @brief SADC interrupt handler
 * @details Clear the SADC interrupt status and handle the SADC interrupt routine
 * @param None
 * @return None
 */
void Sadc_Handler(void)
{
    sadc_cb_t cb;
    sadc_int_t reg_sadc_int_status;

    reg_sadc_int_status.reg = SADC->SADC_INT_STATUS.reg;
    SADC->SADC_INT_CLEAR.reg = reg_sadc_int_status.reg;

    if (reg_sadc_int_status.reg != 0) {
        if (reg_sadc_int_status.bit.DONE == 1) {
        }
        if (reg_sadc_int_status.bit.VALID == 1) {
            if(sadc_reg_handler != NULL) {
                cb.type = SADC_CB_SAMPLE;
                cb.data.sample.value = SADC_GET_ADC_VALUE();
                cb.data.sample.channel = SADC_GET_ADC_CHANNEL();
                sadc_reg_handler(&cb);
            }
        }
        if (reg_sadc_int_status.bit.MODE_DONE == 1) {
            if (SADC_GET_SAMPLE_MODE() == SADC_SAMPLE_START) {
                sadc_convert_state = SADC_CONVERT_DONE;
            }

            if(sadc_reg_handler != NULL) {
                cb.type = SADC_CB_DONE;
                cb.data.done.p_buffer = (sadc_value_t *)(SADC_GET_XDMA_START_ADDRESS());
                cb.data.done.size = SADC_GET_XDMA_RESULT_NUMBER();
                sadc_reg_handler(&cb);
            }
        }
        if (reg_sadc_int_status.bit.WDMA == 1) {
        }
        if (reg_sadc_int_status.bit.WDMA_ERROR == 1) {
        }
    }

    return;
}


/**
 * @brief SADC interrupt service routine callback for user application.
 * @param[in] sadc_int_callback SADC interrupt callback handler
 * @return None
 */
void Sadc_Register_Int_Callback(sadc_isr_handler_t sadc_int_callback)
{
    sadc_reg_handler = sadc_int_callback;

    return;
}


/**
 * @brief Enable the specified SADC interrupts
 * @param[in] int_mask Specifies the SADC interrupt sources to be enabled
 *   This parameter can be any combination of the following values:
 *     @arg SADC_WDMA: SADC WDMA interrupt mask
 *     @arg SADC_WDMA_ERROR: SADC WDMA error interrupt mask
 *     @arg SADC_DONE: SADC conversion done interrupt mask
 *     @arg SADC_VALID: SADC conversion valid interrupt mask
 *     @arg SADC_MODE_DONE: SADC scan mode done interrupt mask
 *     @arg SADC_MONITOR_LOW: SADC monitor low interrupt mask for CH0 ~ CH9
 *     @arg SADC_MONITOR_HIGH: SADC monitor high interrupt mask for CH0 ~ CH9
 * @return None
 */
void Sadc_Int_Enable(uint32_t int_mask)
{
    SADC->SADC_INT_CLEAR.reg = SADC_INT_CLEAR_ALL;
    SADC->SADC_INT_MASK.reg = int_mask;
    NVIC_EnableIRQ((IRQn_Type)(Sadc_IRQn));
    return;
}


/**
 * @brief Disable all SADC interrupt(s)
 * @param None
 * @return None
 */
void Sadc_Int_Disable(void)
{
    NVIC_DisableIRQ((IRQn_Type)(Sadc_IRQn));
    SADC->SADC_INT_MASK.reg = SADC_INT_DISABLE_ALL;
    SADC->SADC_INT_CLEAR.reg = SADC_INT_CLEAR_ALL;
    return;
}


/**
 * @brief Configure the SADC to be ready for convert the input from selected channel
 * @param[in] ch_sel SADC input channel selection: SADC input channel index is from CH0 to CH9
 * @param[in] pi_sel SADC P channel selection: AIN0~AIN9 and no connection
 * @param[in] ni_sel SADC N channel selection: AIN0~AIN9 and no connection
 * @param[in] gain SADC VGA gain selection
 * @param[in] pull SADC P/N channels pull high/low selection
 * @param[in] tacq SADC result acquisition time
 * @param[in] edly SADC end delay time
 * @param[in] burst SADC take 2^Oversample number of sample and average for conversion: Single mode and Burst mode
 * @param[in] low_thd SADC analog monitor low threshold: 0~0x3FFF
 * @param[in] high_thd SADC analog monitor high threshold: 0~0x3FFF
 * @return  None
 */
void Sadc_Channel_Enable(sadc_channel_config_t *config_channel)
{
    volatile sadc_pnsel_ch_t *sadc_pnsel_ch;
    volatile sadc_set_ch_t *sadc_set_ch;
    volatile sadc_thd_ch_t *sadc_thd_ch;
    #if (SADC_ANALOG_ENABLE == 1)
    //uint32_t gpio_pull_ctrl_offset = 0;
    uint32_t gpio_pull_ctrl_bit = 0;
    #endif

    sadc_pnsel_ch = &(SADC->SADC_PNSEL_CH0) + (config_channel->ch_sel * SADC_CH_REG_OFFSET);
    sadc_set_ch = &(SADC->SADC_SET_CH0) + (config_channel->ch_sel * SADC_CH_REG_OFFSET);
    sadc_thd_ch = &(SADC->SADC_THD_CH0) + (config_channel->ch_sel * SADC_CH_REG_OFFSET);

    #if (SADC_ANALOG_ENABLE == 1)
    /*
    if (config_channel->pi_sel == config_channel->ni_sel) {
        return;
    }
    */

    #if (SADC_VGA_BYPASS == 1)
    SADC->SADC_SET1.bit.CFG_SADC_TST_MANUAL = ENABLE;
    PMU->PMU_COMP0.bit.AUX_TEST_MODE = ENABLE;
    SYSCTRL->GPIO_PULL_CTRL[2] &= (~(0x00000007 << 24));    //no pull
    SYSCTRL->GPIO_PULL_CTRL[2] &= (~(0x00000007 << 28));    //no pull
    #endif

    /*
    if (config_channel->pi_sel < SADC_AIN_DISABLED) {
        gpio_pull_ctrl_offset = (config_channel->pi_sel >> 3);
        gpio_pull_ctrl_bit = (config_channel->pi_sel & 0x07) * 4;
        SYSCTRL->GPIO_PULL_CTRL[gpio_pull_ctrl_offset] &= (~(0x00000007 << gpio_pull_ctrl_bit));    //no pull

        SYSCTRL->GPIO_AIO_CTRL |= (0x00000001 << config_channel->pi_sel);    //enable AIO
    }

    if (config_channel->ni_sel < SADC_AIN_DISABLED) {
        gpio_pull_ctrl_offset = (config_channel->ni_sel >> 3);
        gpio_pull_ctrl_bit = (config_channel->ni_sel & 0x07) * 4;
        SYSCTRL->GPIO_PULL_CTRL[gpio_pull_ctrl_offset] &= (~(0x00000007 << gpio_pull_ctrl_bit));    //no pull

        SYSCTRL->GPIO_AIO_CTRL |= (0x00000001 << config_channel->ni_sel);    //enable AIO
    }
    */

    if (config_channel->pi_sel < SADC_AIN_8) {
        gpio_pull_ctrl_bit = config_channel->pi_sel * 4;
        SYSCTRL->GPIO_PULL_CTRL[3] &= (~(0x00000007 << gpio_pull_ctrl_bit));    //no pull

        SYSCTRL->GPIO_AIO_CTRL |= (0x00000001 << config_channel->pi_sel);    //enable AIO
    }

    if (config_channel->ni_sel < SADC_AIN_8) {
        gpio_pull_ctrl_bit = config_channel->ni_sel * 4;
        SYSCTRL->GPIO_PULL_CTRL[3] &= (~(0x00000007 << gpio_pull_ctrl_bit));    //no pull

        SYSCTRL->GPIO_AIO_CTRL |= (0x00000001 << config_channel->ni_sel);    //enable AIO
    }

    if ((config_channel->pi_sel == SADC_TEMPERATURE) || (config_channel->ni_sel == SADC_TEMPERATURE)) {
        Sadc_Temperature_Enable();
    }
    #endif

    sadc_pnsel_ch->bit.CFG_SADC_PSEL_CH = config_channel->pi_sel;
    sadc_pnsel_ch->bit.CFG_SADC_NSEL_CH = config_channel->ni_sel;
    sadc_pnsel_ch->bit.CFG_SADC_GAIN_CH = config_channel->gain;
    sadc_pnsel_ch->bit.CFG_SADC_PULL_CH = config_channel->pull;
    sadc_pnsel_ch->bit.CFG_SADC_TACQ_CH = config_channel->tacq;
    sadc_pnsel_ch->bit.CFG_SADC_EDLY_CH = config_channel->edly;

    sadc_set_ch->bit.CFG_SADC_BURST_CH = config_channel->burst;

    sadc_thd_ch->bit.CFG_SADC_LTHD_CH = config_channel->low_thd;
    sadc_thd_ch->bit.CFG_SADC_HTHD_CH = config_channel->high_thd;

    return;
}


/**
 * @brief Close the SADC to convert the input from selected channel
 * @param[in] ch_sel SADC input channel selection: SADC input channel index is from CH0 to CH9
 * @return None
 */
void Sadc_Channel_Disable(sadc_config_channel_t ch_sel)
{
    volatile sadc_pnsel_ch_t *sadc_pnsel_ch;
    volatile sadc_set_ch_t *sadc_set_ch;
    volatile sadc_thd_ch_t *sadc_thd_ch;

    sadc_pnsel_ch = &(SADC->SADC_PNSEL_CH0) + (ch_sel * SADC_CH_REG_OFFSET);
    sadc_set_ch = &(SADC->SADC_SET_CH0) + (ch_sel * SADC_CH_REG_OFFSET);
    sadc_thd_ch = &(SADC->SADC_THD_CH0) + (ch_sel * SADC_CH_REG_OFFSET);

    sadc_pnsel_ch->reg = SADC_PNSEL_CH_REG_DEFAULT;
    sadc_set_ch->reg = SADC_SET_CH_REG_DEFAULT;
    sadc_thd_ch->reg = SADC_THD_CH_REG_DEFAULT;

    return;
}


/**
 * @brief Configure the SADC XDMA request
 * @param[in] xdma_start_addr The start address of the specified SADC XDMA buffer
 * @param[in] xdma_seg_size The segment size of the specified SADC XDMA buffer
 * @param[in] xdma_blk_size The block size of the specified SADC XDMA buffer
 * @return None
 */
void Sadc_Xdma_Config(uint32_t xdma_start_addr,
                      uint16_t xdma_seg_size,
                      uint16_t xdma_blk_size)
{
    /*Reset XDMA*/
    SADC->SADC_WDMA_CTL1.bit.CFG_SADC_WDMA_CTL1 = ENABLE;

    /*Clear XDMA IRQ*/
    SADC->SADC_INT_CLEAR.bit.WDMA = ENABLE;
    SADC->SADC_INT_CLEAR.bit.WDMA_ERROR = ENABLE;

    /*Enable XDMA IRQ*/
    /*
    SADC->SADC_INT_MASK.bit.WDMA = 0;
    SADC->SADC_INT_MASK.bit.WDMA_ERROR = 0;
    */

    /*Set XDMA buffer address*/
    SADC->SADC_WDMA_SET1 = xdma_start_addr;

    /*Set XDMA buffer size*/
    SADC->SADC_WDMA_SET0.bit.CFG_SADC_SEG_SIZE = xdma_seg_size;
    SADC->SADC_WDMA_SET0.bit.CFG_SADC_BLK_SIZE = xdma_blk_size;

    /*Start XDMA for memory access*/
    SADC_SET_XDMA_START();

    return;
}

#if (SADC_ANALOG_ENABLE == 1)
void Sadc_Analog_Init(void)
{
    SADC->SADC_ANA_SET0.bit.CFG_AUX_ANA_SET0 = 0x70908;

    SADC->SADC_ANA_SET1.bit.CFG_AUX_PDC = 0x10;
    SADC->SADC_ANA_SET1.bit.CFG_AUX_NDC = 0x10;
    SADC->SADC_ANA_SET1.bit.CFG_AUX_PW = 0x36;
    SADC->SADC_ANA_SET1.bit.CFG_EN_CLKAUX = ENABLE;

    /*
    PMU->PMU_PWR_CTRL.bit.EN_DCDC_NM = DISABLE;
    PMU->PMU_PWR_CTRL.bit.EN_LLDO_NM = ENABLE;
    */
}
#endif

void Sadc_Temperature_Enable(void)
{
    #if (SUPPORT_SADC_TEMPERATURE == 1)
    uint32_t pBuffer;

    commsubsystem_dma_init();

    commsubsystem_read_memory(0x330, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 5);
    commsubsystem_write_memory(0x330, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x314, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 6);
    pBuffer &= (~(1 << 7));
    commsubsystem_write_memory(0x314, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x334, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 8);
    commsubsystem_write_memory(0x334, (uint8_t *)&pBuffer, 4);

    PMU->PMU_TS.bit.CLKTS_EN = ENABLE;
    PMU->PMU_TS.bit.EN_TS = ENABLE;
    PMU->PMU_COMP0.bit.AUX_EN_START = 3;
    PMU->PMU_COMP0.bit.AUX_EN_START = 2;
    PMU->PMU_TS.bit.TS_RST = ENABLE;
    PMU->PMU_TS.bit.TS_RST = DISABLE;
    PMU->PMU_TS.bit.TS_VX = 4;
    PMU->PMU_TS.bit.TS_S = 4;
    #endif

    //***********************************************
    #if (0)
    commsubsystem_read_memory(0x350, (uint8_t *)&pBuffer, 4);
    pBuffer &= (~(1 << 15));
    commsubsystem_write_memory(0x350, (uint8_t *)&pBuffer, 4);

    PMU->PMU_TS.bit.CLKTS_EN = ENABLE;
    PMU->PMU_TS.bit.CLKTS_SEL = DISABLE;

    commsubsystem_read_memory(0x314, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 6);
    commsubsystem_write_memory(0x314, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x330, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 5);
    commsubsystem_write_memory(0x330, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x30C, (uint8_t *)&pBuffer, 4);
    pBuffer &= (~(1 << 9));
    commsubsystem_write_memory(0x30C, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x30C, (uint8_t *)&pBuffer, 4);
    pBuffer &= (~(1 << 1));
    commsubsystem_write_memory(0x30C, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x334, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 8);
    commsubsystem_write_memory(0x334, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x43C, (uint8_t *)&pBuffer, 4);
    pBuffer |= (1 << 13);
    pBuffer &= (~(1 << 12));
    commsubsystem_write_memory(0x43C, (uint8_t *)&pBuffer, 4);

    commsubsystem_read_memory(0x424, (uint8_t *)&pBuffer, 4);
		pBuffer &= 0xFFFFFF00;
    pBuffer |= 0x0000003F;
    commsubsystem_write_memory(0x424, (uint8_t *)&pBuffer, 4);
    #endif

    //***********************************************
}

uint32_t Sadc_Init(sadc_config_t *p_config, sadc_isr_handler_t sadc_int_callback)
{
    if (p_config == NULL) {
        return STATUS_INVALID_PARAM;
    }

    sadc_xdma_single_mode = DISABLE;
    sadc_convert_state = SADC_CONVERT_IDLE;

    SADC_RESET();                                       /*Reset SADC*/

    #if (SADC_ANALOG_ENABLE == 1)
    Sadc_Analog_Init();
    #endif

    SADC_RES_BIT(p_config->sadc_resolution);            /*Set SADC resolution bit*/

    SADC_OVERSAMPLE_RATE(p_config->sadc_oversample);    /*Set SADC oversample rate*/

    if (p_config->sadc_xdma.enable == ENABLE) {
        Sadc_Xdma_Config(p_config->sadc_xdma.start_addr, p_config->sadc_xdma.seg_size, p_config->sadc_xdma.blk_size);

        if (p_config->sadc_xdma.blk_size == 0) {
            sadc_xdma_single_mode = ENABLE;
        }
    }

    if (sadc_int_callback != NULL) {
        Sadc_Register_Int_Callback(sadc_int_callback);
    }
    Sadc_Int_Enable(p_config->sadc_int_mask.reg);

    SADC_SAMPLE_MODE(p_config->sadc_sample_mode);                    /*Sample rate depends on timer rate*/
    if (p_config->sadc_sample_mode == SADC_SAMPLE_TIMER) {
        SADC_TIMER_CLOCK(p_config->sadc_timer.timer_clk_src);        /*Timer clock source = system clock*/
        SADC_TIMER_CLOCK_DIV(p_config->sadc_timer.timer_clk_div);    /*Timer rate configuration*/
    }

    #if (SADC_TEST_MODE == 1)
    SADC_TEST_ENABLE();
    SADC_TEST_ADJUST_VALUE(SADC_TEST_VALUE);
    #elif (SADC_CALIBRATION_VALUE != 0)
    SADC_TEST_ADJUST_VALUE((uint32_t)SADC_CALIBRATION_VALUE);
    #endif

    return STATUS_SUCCESS;
}

void Sadc_Enable(void)
{
    SADC_ENABLE();       /*Enable SADC*/

    return;
}

void Sadc_Start(void)
{
    if (sadc_xdma_single_mode == ENABLE) {
        SADC_SET_XDMA_START();
    }

    sadc_convert_state = SADC_CONVERT_START;

    SADC_START();        /*Start to trigger SADC*/

    return;
}

uint32_t Sadc_Resolution_Compensation(sadc_value_t *p_data)
{
    uint32_t compensation_bit = 0;

    if (p_data == NULL) {
        return STATUS_INVALID_PARAM;
    }

    switch (SADC_GET_RES_BIT()) {
        case SADC_RES_8BIT:
            compensation_bit = 6;
            break;

        case SADC_RES_10BIT:
            compensation_bit = 4;
            break;

        case SADC_RES_12BIT:
            compensation_bit = 2;
            break;

        case SADC_RES_14BIT:
            break;

        default:
            break;
    }

    (*p_data) >>= compensation_bit;

    return STATUS_SUCCESS;
}

sadc_convert_state_t Sadc_Convert_State_Get(void)
{
    return sadc_convert_state;
}

/** @} */
