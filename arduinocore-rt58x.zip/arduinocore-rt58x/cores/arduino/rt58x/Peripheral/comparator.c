/** @file
 *
 * @brief Comparator driver file.
 *
 */

/**
 * @defgroup Comparator Group
 * @{
 * @brief    Comparator group.
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include "cm3_mcu.h"


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
static comp_isr_handler_t   comp_reg_handler = NULL;


/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/

/**
 * @brief Comparator interrupt handler
 * @details Clear the Comparator interrupt status and handle the Comparator interrupt routine
 * @param None
 * @return None
 */
void Comp_Handler(void)
{
    if (COMP_INT_STATUS_GET()) {
        COMP_INT_CLEAR();

        if (COMP_INT_STATUS_GET()) {
            ASSERT();
        }

        if(comp_reg_handler != NULL) {
            comp_reg_handler();
        }
    }
    return;
}


/**
 * @brief Comparator interrupt service routine callback for user application.
 * @param[in] comp_int_callback Comparator interrupt callback handler
 * @return None
 */
void Comp_Register_Int_Callback(comp_isr_handler_t comp_int_callback)
{
    comp_reg_handler = comp_int_callback;

    return;
}


/**
 * @brief Enable the specified Comparator interrupts
 * @param[in] int_mask Specifies the Comparator interrupt sources to be enabled
 * @return None
 */
void Comp_Int_Enable(void)
{
    COMP_INT_CLEAR();
    COMP_INT_ENABLE();
    NVIC_EnableIRQ((IRQn_Type)(Comp_IRQn));

    return;
}


/**
 * @brief Disable all Comparator interrupt(s)
 * @param None
 * @return None
 */
void Comp_Int_Disable(void)
{
    NVIC_DisableIRQ((IRQn_Type)(Comp_IRQn));
    COMP_INT_DISABLE();
    COMP_INT_CLEAR();

    return;
}


uint32_t Comp_Init(comp_config_t *p_config, comp_isr_handler_t comp_int_callback)
{
    if (p_config == NULL) {
        return STATUS_INVALID_PARAM;
    }

    COMP_INT_POL(p_config->comp_int_pol);            /*Set Comparator interrupt polarity*/
    COMP_CH_SEL(p_config->comp_ch_sel);              /*Select Comparator AIO channel for comparision*/
    COMP_V_SEL(p_config->comp_v_sel);                /*Select Comparator VCCIO voltage to compare with selected AIO channel*/

    if (comp_int_callback != NULL) {
        Comp_Register_Int_Callback(comp_int_callback);
    }
    Comp_Int_Enable();

    return STATUS_SUCCESS;
}


void Comp_Enable(void)
{
    COMP_ENABLE();       /*Enable Comparator*/

    return;
}


/** @} */
