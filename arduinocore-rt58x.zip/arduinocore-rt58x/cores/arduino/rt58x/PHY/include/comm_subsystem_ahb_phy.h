/**************************************************************************//**
 * @file     COMM_SUBSYSTEM_AHB.h
 * @version
 * @brief    communication_subsystem.h file
 *
 ******************************************************************************/

#ifndef __COMM_SUBSYSTEM_AHB_H__
#define __COMM_SUBSYSTEM_AHB_H__
#include "cm3_mcu.h"
#ifdef __cplusplus
extern "C"
{
#endif

#define COMM_SUBSYS_NEW                     (FALSE)
#define COMM_SUBSYS_AHB_USING_MUTEX         (FALSE)

#define COMM_SUBSYSTEM_DMA_INT_ENABLE       (BIT8)
#define COMM_SUBSYSTEM_DMA_INT_CLR          (COMM_SUBSYSTEM_DMA_INT_ENABLE)
#define COMM_SUBSYSTEM_SYS_RDY              (BIT0)

#define COMM_SUBSYS_TX_CMD_QUEUE_ID         (7)
#define COMM_SUBSYS_RX_CMD_QUEUE_ID         (1)
#define COMM_SUBSYS_RX_QUEUE_ID             (0)
#define COMM_SUBSYS_MCU_INIT_SUCCEED_2      (0xEA)

#define COMM_SUBSYSTEM_INT_ALL_MASK         (0x1FF)
#define COMM_SUBSYSTEM_INT_ENABLE           (0x7F)//(0xFF)
#define COMM_SUBSYSTEM_INT_STATUS_MASK      (COMM_SUBSYSTEM_INT_ENABLE)
#define COMM_SUBSYSTEM_DMA_IS_BUSY          (BIT16)

#define COMM_SUBSYS_TX_CMD_Q_AVAILABLE      (BIT7)
#define COMM_SUBSYS_RX_CMD_Q_AVAILABLE      (BIT1)
#define COMM_SUBSYS_RX_Q_AVAILABLE          (BIT0)

#define COMM_SUBSYS_MAX_RX_Q_LEN            (0xFFF)
#define COMM_SUBSYS_MAX_RX_CMDQ_LEN         (0xFFF)
#define COMM_SUBSYS_PROGRAM_START_ADDR      (0x8000)
#define COMM_SUBSYS_FW_PAGE_SIZE            (0x8000)

#define RF_MCU_PM_SEL_REG_ADDR              (0x0448)

/* The register are DMA transfer type */
typedef uint8_t COMM_SUBSYS_DMA_TYPE;
#define COMM_SUBSYSTEM_DMA_TYPE_IO_READ                (COMM_SUBSYS_DMA_TYPE)(0x0) // Move data from RX FIFO to Host memory
#define COMM_SUBSYSTEM_DMA_TYPE_IO_WRITE               (COMM_SUBSYS_DMA_TYPE)(0x1) // Move data from TX FIFO to commsubsystem memory
#define COMM_SUBSYSTEM_DMA_TYPE_MEM_READ               (COMM_SUBSYS_DMA_TYPE)(0x2) // Move data from commsubsystem memory to Host memory
#define COMM_SUBSYSTEM_DMA_TYPE_MEM_WRITE              (COMM_SUBSYS_DMA_TYPE)(0x3) // Move data from Host memory to commsubsystem memory

/* The register are defined to control commsubsystem by Host, each of bit is WRITE only.*/
#define COMM_SUBSYSTEM_HOST_CTRL_WAKE_UP               0x00000100             /**< bit8 */
#define COMM_SUBSYSTEM_HOST_CTRL_SLEEP_EN              0x00000200             /**< bit9 */
#define COMM_SUBSYSTEM_HOST_CTRL_DEEP_SLEEP_EN         0x00000400             /**< bit10 */
#define COMM_SUBSYSTEM_HOST_CTRL_RESET                 0x00000800             /**< bit11 */
#define COMM_SUBSYSTEM_HOST_CTRL_DMA_ENABLE            0x00010000             /**< bit16 */
#define COMM_SUBSYSTEM_HOST_CTRL_ENABLE_HOST_MODE      0x01000000             /**< bit24 */
#define COMM_SUBSYSTEM_HOST_CTRL_DISABLE_HOST_MODE     0x02000000             /**< bit25 */


typedef enum rf_mcu_init_status_e {
    RF_MCU_INIT_NO_ERROR           = 0,
    RF_MCU_FIRMWARE_LOADING_FAIL,
    RF_MCU_CPU_AWAKE_FAIL,
} RF_MCU_INIT_STATUS;


typedef enum rf_mcu_tx_queue_err_e {
    RF_MCU_TXQ_ERR_INIT             = 0,
    RF_MCU_TXQ_SET_SUCCESS,
    RF_MCU_TXQ_FULL,
} RF_MCU_TXQ_ERROR;


typedef enum rf_mcu_tx_cmd_err_e {
    RF_MCU_TX_CMDQ_ERR_INIT         = 0,
    RF_MCU_TX_CMDQ_SET_SUCCESS,
    RF_MCU_TX_CMDQ_FULL,
} RF_MCU_TX_CMDQ_ERROR;


typedef enum rf_mcu_rx_queue_err_e {
    RF_MCU_RXQ_ERR_INIT             = 0,
    RF_MCU_RXQ_GET_SUCCESS,
    RF_MCU_RXQ_NOT_AVAILABLE,
} RF_MCU_RXQ_ERROR;


typedef enum rf_mcu_rx_cmd_err_e {
    RF_MCU_RX_CMDQ_ERR_INIT         = 0,
    RF_MCU_RX_CMDQ_GET_SUCCESS,
    RF_MCU_RX_CMDQ_NOT_AVAILABLE,
} RF_MCU_RX_CMDQ_ERROR;


typedef enum rf_mcu_pwr_state_e {
    RF_MCU_PWR_STATE_TRANSITION     = 0x0,
    RF_MCU_PWR_STATE_DEEP_SLEEP,
    RF_MCU_PWR_STATE_SLEEP,
    RF_MCU_PWR_STATE_NORMAL,
} RF_MCU_PWR_STATE;


typedef enum rf_mcu_pm_page_sel_e {
    RF_MCU_PM_PAGE_SEL_0            = 0,
    RF_MCU_PM_PAGE_SEL_1,
} RF_MCU_PM_PAGE_SEL;


typedef enum _rf_mcu_state {
    RF_MCU_STATE_NULL               = 0,
    RF_MCU_STATE_INIT_SUCCEED       = BIT0,
    RF_MCU_STATE_EVENT_DONE         = BIT1,
    RF_MCU_STATE_TX_FAIL            = BIT2,
    RF_MCU_STATE_RSVD_BIT3          = BIT3,
    RF_MCU_STATE_TX_CSMACA_FAIL     = BIT4,
    RF_MCU_STATE_TX_NO_ACK          = BIT5,
    RF_MCU_STATE_TX_SUC_AR_FP       = BIT6,
    RF_MCU_STATE_TX_SUC_AR          = BIT7,
} RF_MCU_STATE;


typedef void (* COMM_SUBSYSTEM_ISR_t)(uint8_t interrupt_state_value);


typedef struct {
    /*Because the callback function feature, the COMM_SUBSYSTEM_Handler NOW would not take responsibilty for cleaning the interrupt status.
        The ISR must take charge for cleaning the interrupt status itself.
        The ISR writer must take care this thing.
    */
    COMM_SUBSYSTEM_ISR_t  commsubsystem_isr;           /**< user application ISR handler. */
    uint32_t  content;
} COMM_SUBSYSTEM_ISR_CONFIG;


typedef union {
    uint8_t u8;
    struct _comm_subsystem_interrupt {
        uint8_t EVENT_DONE : 1;
        uint8_t TX_DONE : 1;
        uint8_t RFB_TRAP : 1;
        uint8_t RX_TIMEOUT : 1;
        uint8_t MHR_DONE : 1;
        uint8_t RX_DONE : 1;
        uint8_t SPI_DATA_TRANSFER_ERROR : 1;
        uint8_t RTC_WAKEUP : 1;
    } bf; // bit-field
} COMM_SUBSYSTEM_INTERRUPT;


/**
 * @brief To clean the interrupts of  comm subsystem by input bits.
 *
 * @param uint8_t value, the bit field which would clean the corresponding interrupt.
 *
 * @return none
 *
 * @date 04 Dec 2019
 * @see
 * @image
 */
#if (COMM_SUBSYS_NEW)
void commsubsystem_clean_interrupt(uint32_t value);
#else
void commsubsystem_clean_interrupt(uint8_t value);
#endif
/**
 * @brief To check whether a pakcet is available to be send or not
 *
 * @return TRUE or FALSE.
 * @date 04 Dec 2019
 * @see
 * @image
 */
uint8_t commsubsystem_check_tx_queue_full(void);
/**
 * @brief To send a packet to the communication subsystem.
 *
 * @param uint8_t q_id, Q ID of TxQ, range from 0 to 6.
 * @param constuint8_t* tx_q_content, the source of transmitting data and corresponding information.
 * @param uint32_t tx_q_length, size of transmitting data and corresponding information (in byte).
 *
 * @return RF_MCU_TX_CMDQ_SET_SUCCESS or RF_MCU_TX_CMDQ_FULL.
 * @date 04 Dec 2019
 * @see
 * @image
 */

uint8_t commsubsystem_check_power_state(void);
void commsubsystem_host_wakeup(void);
uint8_t commsubsystem_get_sfr(uint8_t sfrOffset);
void commsubsystem_set_sfr(uint8_t sfrOffset, uint8_t value);
void commsubsystem_io_read(uint16_t Q_id,  uint8_t *p_rx_data, uint16_t rx_data_length);
void commsubsystem_io_write(uint8_t Q_id, const uint8_t *p_tx_data, uint16_t tx_data_length);
void commsubsystem_mem_read(uint16_t reg_address, uint8_t *p_rx_data, uint16_t rx_data_length);
void commsubsystem_mem_write(uint16_t reg_address, const uint8_t *p_tx_data, uint16_t tx_data_length);
void commsubsystem_read_memory_from_isr(uint16_t reg_address, uint8_t *p_rx_data, uint16_t rx_data_length);
bool commsubsystem_check_cmd_queue_full(void);

RF_MCU_TXQ_ERROR commsubsystem_send_tx_queue(uint8_t q_id, const uint8_t *tx_q_content, uint32_t tx_q_length);
/**
 * @brief To send a cmd to the communication subsystem.
 *
 * @param const uint8_t *cmd, the source of cmd.
 * @param uint32_t cmd_length, size of cmd (in byte).
 * @date 04 Dec 2019
 * @see
 * @image
 */
RF_MCU_TX_CMDQ_ERROR commsubsystem_send_cmd_queue(const uint8_t *cmd, uint32_t cmd_length);
/**
 * @brief To read corresponding information from the communication subsystem.
 *
 * @param uint8_t* rx_q, a buffer to store corresponding information read from the communication subsystem.
 * @param RF_MCU_RX_CMDQ_ERROR *rx_cmd_error, the error code to check the status of receiving from the communication subsystem.
 *
 * @return uint16_t rx_q_length, size of the corresponding information (in byte).
 * @date 04 Dec 2019
 * @see
 * @image
 */
uint16_t commsubsystem_read_cmd_queue(uint8_t *rx_q, RF_MCU_RX_CMDQ_ERROR *rx_cmd_error);
/**
 * @brief To read a packet from the communication subsystem.
 *
 * @param uint8_t* rx_q, a buffer to store the data and corresponding information read from the communication subsystem.
 * @param RF_MCU_RXQ_ERROR *rx_q_error, the error code to check the status of receiving the communication subsystem.
 *
 * @return uint16_t rx_q_length
 * @date 04 Dec 2019
 * @see
 * @image
 */
uint16_t commsubsystem_read_rx_queue(uint8_t *rx_q, RF_MCU_RXQ_ERROR *rx_q_error);
/**
 * @brief To check whether a pakcet is available to be read or not
 *
 * @return boolean value, TRUE: At least a pakcet is available to be read, FALSE: the communication subsystem does not receive any packets.
 * @date 04 Dec 2019
 * @see
 * @image
 */

bool commsubsystem_check_rx_queue(void);
/**
 * @brief To send a host state to the communication subsystem.
 *
 * @param cmd: 8bit host state
 *
 * @return boolean value, TRUE: success, FALSE: failure
 * @date 04 Dec 2019
 * @see
 * @image
 */
bool commsubsystem_send_host_cmd(uint8_t cmd);
/**
 * @brief To read mcu state in the ISR
 *
 * @param none
 *
 * @return RF_MCU_STATE
 *
 * @date 04 Dec 2019
 * @see
 * @image
 */
RF_MCU_STATE commsubsystem_read_mcu_state(void);
/**
 * @brief To initialize the communication subsystem.
 *
 * @param none
 *
 * @return RF_MCU_STATE_INIT_SUCCEED/Other error code
 *
 * @date 04 Dec 2019
 * @see
 * @image
 */
//RF_MCU_INIT_STATUS commsubsystem_init(const uint8_t *comm_subsystem_firmware, uint32_t firmware_size, COMM_SUBSYSTEM_ISR_CONFIG comm_subsystem_isr_cfg);
RF_MCU_INIT_STATUS commsubsystem_init(
    bool load_fw,
    const uint8_t *comm_subsystem_firmware,
    uint32_t firmware_size,
    COMM_SUBSYSTEM_ISR_CONFIG comm_subsystem_isr_cfg,
    RF_MCU_INIT_STATUS wait_mcu_state
);
/**
 * @brief To initialize the communication subsystem AHB.
 *
 * @param none
 *
 * @return none
 *
 * @date 04 Dec 2019
 * @see
 * @image
 */
void commsubsystem_wake_up(void);
void commsubsystem_dma_init(void);
void myUSART_callback(uint32_t event);
/**
 * @brief To report the power state of commsubsystem.
 *
 * @param none
 *
 * @return RF_MCU_PWR_STATE
 *
 * @date 20 Nov 2020
 * @see
 * @image
 */
RF_MCU_PWR_STATE commsubsystem_report_powerstate(void);


/**
 * @brief Read interrupt setting
 *
 * @param none
 *
 * @return interrupt setting
 *
 * @date
 * @see
 * @image
 */
uint16_t commsubsystem_get_interrupt(void);


/**
 * @brief Update interrupt setting
 *
 * @param none
 *
 * @return none
 *
 * @date
 * @see
 * @image
 */
void commsubsystem_set_interrupt(uint16_t int_enable);

#ifdef __cplusplus
}
#endif

#endif





