/**************************************************************************//**
 * @file     sha256.c
 * @version  
 * @brief    
 *
 * @copyright 
*****************************************************************************/

#include "project_config.h"

#include "cm3_mcu.h"

#include "crypto.h"

#include "sha256.h"

#include <stdio.h>
#include <string.h>

#define  INNER_PAD          0x36                    /*FIPS 198-1 Inner pad*/
#define  OUTER_PAD          0x5C                    /*FIPS 198-1 Inner pad*/



static void rekey(uint8_t *key, const uint8_t *orig_key, unsigned int key_size)
{    
    uint32_t i;

    for (i = 0; i < key_size; ++i) {
        key[i] = INNER_PAD ^ orig_key[i];
        key[i + SHA256_BLOCK_SIZE] = OUTER_PAD ^ orig_key[i];
    }

    for (; i < SHA256_BLOCK_SIZE; ++i) {
        key[i] = INNER_PAD; 
        key[i + SHA256_BLOCK_SIZE] = OUTER_PAD;
    }
}

uint32_t hmac_sha256(const uint8_t *key,
					uint32_t       key_length,
					const uint8_t *msg,
					uint32_t       msg_length,
					uint8_t       *output)
{

    /*output buffer must be more than 32 bytes!!*/

    /*Please notice this function will need stack size over 200 bytes!*/
    sha256_context sha_cnxt;
    
    sha256_starts_rom_t    sha256_starts;
    sha256_update_rom_t    sha256_update;
    sha256_finish_rom_t    sha256_finish;

    uint8_t   sha256_digest[SHA256_DIGEST_SIZE];

    /*ipad and opad, the first 64 bytes is ipad, the next 64 bytes is opad*/
    uint8_t   pad_key[SHA256_BLOCK_SIZE*2];


    if ((key==NULL) ||(key_length==0) || (output==NULL))
        return STATUS_INVALID_PARAM  ;			/*not correct input*/

    memset(pad_key, 0, sizeof(pad_key));
    
    /*Because we use 32bits operation, so msg must be 4-bytes alignment*/
    
    sha256_starts =  (sha256_starts_rom_t )  *((uint32_t*)ROM_START_FUN_ADDR);
    sha256_update = (sha256_update_rom_t)   *((uint32_t*)ROM_UPDATE_FUN_ADDR);
    sha256_finish = (sha256_finish_rom_t)   *((uint32_t*)ROM_FINISH_FUN_ADDR);

	/*check key size*/


	/* if (key_length <= SHA256_BLOCK_SIZE) 
	 * The next three calls are dummy calls just to avoid
	 * certain timing attacks. Without these dummy calls,
	 * adversaries would be able to learn whether the key_length is
	 * greater than SHA256_BLOCK_SIZE by measuring the time
	 * consumed in this process.
	 */
	sha256_starts(&sha_cnxt);
	sha256_update(&sha_cnxt, (uint8_t *) key, key_length);
	sha256_finish(&sha_cnxt, sha256_digest);

	if (key_length <= SHA256_BLOCK_SIZE)
	{
		/* Actual code for when key_size <= SHA256_BLOCK_SIZE: */
		rekey(pad_key, key, key_length);
	}
	else
	{
		rekey(pad_key, sha256_digest, SHA256_DIGEST_SIZE);
	}

	/*FIPS 198-1 step 5.   H( (K_0^ ipad)||text) */
	sha256_starts(&sha_cnxt);
	sha256_update(&sha_cnxt, pad_key, SHA256_BLOCK_SIZE);
	sha256_update(&sha_cnxt, (uint8_t *)msg, msg_length);
	sha256_finish(&sha_cnxt, sha256_digest);

	/*FIPS 198-1 step 9.  H((K_0^opad)||( H( (K_0^ ipad)||text)) */

	sha256_starts(&sha_cnxt);
	sha256_update(&sha_cnxt, (pad_key+SHA256_BLOCK_SIZE) , SHA256_BLOCK_SIZE);
	sha256_update(&sha_cnxt, sha256_digest, SHA256_DIGEST_SIZE);
	sha256_finish(&sha_cnxt, output);

	/*clean data in stack...*/
	memset(pad_key, 0, (SHA256_BLOCK_SIZE*2));
	memset(sha256_digest, 0, SHA256_DIGEST_SIZE);
	memset(&sha_cnxt, 0, sizeof (sha256_context));

	return STATUS_SUCCESS;
}
