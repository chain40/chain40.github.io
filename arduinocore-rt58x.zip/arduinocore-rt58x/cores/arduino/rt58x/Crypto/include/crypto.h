/**************************************************************************//**
 * @file     CRYPTO.h
 * @version  
 * @brief    CRYPTO ACCELEATOR driver header file
 *
 * @copyright 
 ******************************************************************************/
#ifndef ___CRYPTO_H__
#define ___CRYPTO_H__

#include "project_config.h"

#include "cm3_mcu.h"

#include "aes.h"

#include "ecc.h"

#endif

