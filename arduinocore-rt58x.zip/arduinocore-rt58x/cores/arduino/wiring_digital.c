/*
  wiring_digital.c - digital input and output functions
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2005-2006 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  Modified 28 September 2010 by Mark Sproul
*/

#define ARDUINO_MAIN
#include "Arduino.h"
#include "cm3_mcu.h"

void pinMode(uint8_t pin, uint8_t mode)
{
    switch (mode)
    {
    case OUTPUT:
        gpio_cfg_output(pin);
        break;
    case INPUT /* constant-expression */:
        pin_set_pullopt(pin, MODE_PULLUP_100K);
    default:
        gpio_cfg_input(pin, GPIO_PIN_NOINT);
        pin_set_mode(pin, MODE_GPIO);
        break;
    }
}

void digitalWrite(uint8_t pin, uint8_t val)
{
    if (val)
    {
        gpio_pin_set(pin);
    }
    else
    {
        gpio_pin_clear(pin);
    }
}

PinStatus digitalRead(uint8_t pin)
{
    uint32_t pin_state = gpio_pin_get(pin);
    return pin_state == 0 ? LOW : HIGH;
}